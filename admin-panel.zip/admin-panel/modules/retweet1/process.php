<?
define('BASEPATH', true);
include('../../config.php');
if(!$is_online){exit;}

if(isset($_POST['step']) && $_POST['step'] == "skip" && is_numeric($_POST['sid']) && !empty($data['id'])){
	$id = $db->EscapeString($_POST['sid']);
	if($db->QueryGetNumRows("SELECT site_id FROM `retweet1ed` WHERE `user_id`='".$data['id']."' AND `site_id`='".$id."'") == 0){
		$db->Query("INSERT INTO `retweet1ed` (user_id, site_id) VALUES('".$data['id']."', '".$id."')");
		echo '<div class="msg"><div class="info">'.$lang['retwt_03'].'</div></div>';
	}
}

if(isset($_POST['id'])){
	$id = $db->EscapeString($_POST['id']);
	$site = $db->FetchArray($db->Query("SELECT id,user,cpc FROM `retweet1` WHERE `id`='".$id."'"));
	$check = $db->QueryGetNumRows("SELECT site_id FROM `retweet1ed` WHERE `user_id`='".$data['id']."' AND `site_id`='".$site['id']."'");

	if($id != "" && $data['id'] != "" && $check == 0 && $site['cpc'] >= 2){
		$db->Query("UPDATE `users` SET `coins`=`coins`+'".($site['cpc']-1)."' WHERE `id`='".$data['id']."'");
		$db->Query("UPDATE `users` SET `coins`=`coins`-'".$site['cpc']."' WHERE `id`='".$site['user']."'");
		$db->Query("UPDATE `retweet1` SET `clicks`=`clicks`+'1' WHERE `id`='".$id."'");
		$db->Query("UPDATE `web_stats` SET `value`=`value`+'1' WHERE `module_id`='retweet1'");
		$db->Query("INSERT INTO `retweet1ed` (user_id, site_id) VALUES('".$data['id']."','".$site['id']."')");

		if($db->QueryGetNumRows("SELECT uid FROM `user_clicks` WHERE `uid`='".$data['id']."' AND `module`='retweet1' LIMIT 1") == 0){
			$db->Query("INSERT INTO `user_clicks` (`uid`,`module`,`total_clicks`,`today_clicks`)VALUES('".$data['id']."','retweet1','1','1')");
		}else{
			$db->Query("UPDATE `user_clicks` SET `total_clicks`=`total_clicks`+'1', `today_clicks`=`today_clicks`+'1' WHERE `uid`='".$data['id']."' AND `module`='retweet1'");
		}
		echo '<div class="msg"><div class="success">'.lang_rep($lang['retwt_05'], array('-NUM-' => ($site['cpc']-1))).'</div></div>';
	}else{
		echo '<div class="msg"><div class="error">'.$lang['retwt_04'].'</div></div>';
	}
}
?>