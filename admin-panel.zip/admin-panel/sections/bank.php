<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$mesaj = '';
if(isset($_POST['submit'])){
	$currency_code = $db->EscapeString($_POST['currency_code']);
	$convert_enabled = ($_POST['convert_enabled'] > 1 ? 1 : ($_POST['convert_enabled'] < 0 ? 0 : $_POST['convert_enabled']));
	$allow_withdraw = ($_POST['allow_withdraw'] > 1 ? 1 : ($_POST['allow_withdraw'] < 0 ? 0 : $_POST['allow_withdraw']));

	$db->Query("UPDATE `settings` SET `convert_enabled`='".$convert_enabled."', `currency_code`='".$currency_code."', `allow_withdraw`='".$allow_withdraw."'");
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
}
if(isset($_POST['usubmit'])){
	$convert_rate = $db->EscapeString($_POST['convert_rate']);
	$min_convert = $db->EscapeString($_POST['min_convert']);
	$pay_min = $db->EscapeString($_POST['pay_min']);
	$aff_reg_days = $db->EscapeString($_POST['aff_reg_days']);
	$aff_reg_days = ($aff_reg_days < 0 ? 0 : $aff_reg_days);
	
	$db->Query("UPDATE `settings` SET `pay_min`='".$pay_min."', `aff_reg_days`='".$aff_reg_days."', `convert_rate`='".$convert_rate."', `min_convert`='".$min_convert."'");
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
}
?>
<section id="content" class="container_12 clearfix"><?=$mesaj?>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>General Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Payment Currency</strong><small>This currency is used on<br />whole website</small></label>
						<div><select name="currency_code"><option value="USD">USD</option><option value="EUR"<?=($site['currency_code'] == 'EUR' ? ' selected' : '')?>>EUR</option><option value="GBP"<?=($site['currency_code'] == 'GBP' ? ' selected' : '')?>>GBP</option><option value="AUD"<?=($site['currency_code'] == 'AUD' ? ' selected' : '')?>>AUD</option><option value="HUF"<?=($site['currency_code'] == 'HUF' ? ' selected' : '')?>>HUF</option><option value="JPY"<?=($site['currency_code'] == 'JPY' ? ' selected' : '')?>>JPY</option></select></div>
					</div>
					<div class="row">
						<label><strong>Coins to Cash</strong><small>Allow users to convert coins<br />into account balance cash</small></label>
						<div><select name="convert_enabled"><option value="1">Enabled</option><option value="0"<?=($site['convert_enabled'] == 0 ? ' selected' : '')?>>Disabled</option></select></div>
					</div>
					<div class="row">
						<label><strong>Withdraw Money</strong><small>Allow users to withdraw money<br />from account balance</small></label>
						<div><select name="allow_withdraw"><option value="1">Enabled</option><option value="0"<?=($site['allow_withdraw'] == 0 ? ' selected' : '')?>>Disabled</option></select></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="submit" />
					</div>
				</div>
		</form>
	</div>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Other Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Conversion Rate</strong><small>How many coins for $ 1.00</small></label>
						<div><input type="text" name="convert_rate" value="<?=(isset($_POST['convert_rate']) ? $_POST['convert_rate'] : $site['convert_rate'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Minimum Coins</strong><small>Minimum coins amount to be converted</small></label>
						<div><input type="text" name="min_convert" value="<?=(isset($_POST['min_convert']) ? $_POST['min_convert'] : $site['min_convert'])?>" maxlength="5" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Minimum Payout $</strong><small>Minimum payout amount</small></label>
						<div><input type="text" name="pay_min" value="<?=(isset($_POST['pay_min']) ? $_POST['pay_min'] : $site['pay_min'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Registration Days</strong><small>Required days from registration, for payout</small></label>
						<div><input type="text" name="aff_reg_days" value="<?=(isset($_POST['aff_reg_days']) ? $_POST['aff_reg_days'] : $site['aff_reg_days'])?>" required="required" /></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="usubmit" />
					</div>
				</div>
		</form>
	</div>
</section>