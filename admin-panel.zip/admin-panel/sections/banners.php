<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
if(isset($_GET['del']) && is_numeric($_GET['del'])){
	$del = $db->EscapeString($_GET['del']);
	$db->Query("DELETE FROM `banner_packs` WHERE `id`='".$del."'");
}elseif(isset($_GET['b_del']) && is_numeric($_GET['b_del'])){
	$del = $db->EscapeString($_GET['b_del']);
	$db->Query("DELETE FROM `banners` WHERE `id`='".$del."'");
}elseif(isset($_GET['edit'])){
	$edit = $db->EscapeString($_GET['edit']);
	$pack = $db->FetchArray($db->Query("SELECT * FROM `banner_packs` WHERE `id`='".$edit."'"));
	$mesaj = '';
	if(isset($_POST['submit'])){
		$days = $db->EscapeString($_POST['days']);
		$price = $db->EscapeString($_POST['price']);
	
		$db->Query("UPDATE `banner_packs` SET `days`='".$days."', `coins`='".$price."' WHERE `id`='".$edit."'");
		$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Banner Ads pack was successfully edited!</div>';
	}
}elseif(isset($_GET['b_edit'])){
	$edit = $db->EscapeString($_GET['b_edit']);
	$banner = $db->FetchArray($db->Query("SELECT * FROM `banners` WHERE `id`='".$edit."'"));
	$mesaj = '';
	if(isset($_POST['submit'])){
		$banner_url	= $db->EscapeString($_POST['b_url']);
		$site_url = $db->EscapeString($_POST['s_url']);
	
		$db->Query("UPDATE `banners` SET `banner_url`='".$banner_url."', `site_url`='".$site_url."' WHERE `id`='".$edit."'");
		$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Banner was successfully edited!</div>';
	}
}elseif(isset($_GET['add'])){
	$mesaj = '';
	if(isset($_POST['submit'])){
		$days = $db->EscapeString($_POST['days']);
		$price = $db->EscapeString($_POST['price']);
	
		if(is_numeric($days) && $days > 0 && is_numeric($price) && $price > 0){
			$db->Query("INSERT INTO `banner_packs` (days, coins) VALUES('".$days."', '".$price."')");
			$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Banner Ads pack was successfuly added!</div>';
		}else{
			$mesaj = '<div class="alert error"><span class="icon"></span><strong>Error!</strong> You have to complete all fields!</div>';
		}
	}
}
if(isset($_GET['edit']) && $pack['id'] != ''){
?>
<section id="content" class="container_12 clearfix" data-sort=true><?=$mesaj?>
	<div class="grid_12">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Edit Pack</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Days</strong></label>
						<div><input type="text" name="days" value="<?=(isset($_POST['days']) ? $_POST['days'] : $pack['days'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Price (coins)</strong></label>
						<div><input type="text" name="price" value="<?=(isset($_POST['price']) ? $_POST['price'] : $pack['coins'])?>" required="required" /></div>
					</div>
				</div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="submit" />
					</div>
				</div>
		</form>
	</div>
</section>							
<?}elseif(isset($_GET['b_edit']) && $banner['id'] != ''){?>
<section id="content" class="container_12 clearfix" data-sort=true><?=$mesaj?>
	<div class="grid_12">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Edit Banner</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Expiration date</strong></label>
						<div><input type="text" value="<?=($banner['expiration'] == 0 ? 'Expired' : date('d-m-Y H:i', $banner['expiration']))?>" disabled /></div>
					</div>
					<div class="row">
						<label><strong>Banner URL</strong></label>
						<div><input type="text" name="b_url" value="<?=(isset($_POST['b_url']) ? $_POST['b_url'] : $banner['banner_url'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Site URL</strong></label>
						<div><input type="text" name="s_url" value="<?=(isset($_POST['s_url']) ? $_POST['s_url'] : $banner['site_url'])?>" required="required" /></div>
					</div>
				</div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="submit" />
					</div>
				</div>
		</form>
	</div>
</section>
<?}elseif(isset($_GET['add'])){?>
<section id="content" class="container_12 clearfix" data-sort=true><?=$mesaj?>
	<div class="grid_12">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Add Pack</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Days</strong></label>
						<div><input type="text" name="days" value="0" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Price (coins)</strong></label>
						<div><input type="text" name="price" value="0" required="required" /></div>
					</div>
				</div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="submit" />
					</div>
				</div>
		</form>
	</div>
</section>	
<?}elseif(isset($_GET['packs'])){?>
<section id="content" class="container_12 clearfix ui-sortable" data-sort=true>
		<h1 class="grid_12">Banner Packs</h1>
			<div class="grid_12">
				<div class="box">
                    <table class="styled">
                        <thead>
                            <tr>
                                <th width="25">ID</th>
                                <th>Days</th>
                                <th>Price (coins)</th>
								<th width="120">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
<?
  $sql = $db->Query("SELECT * FROM `banner_packs` ORDER BY `id` ASC");
  for($j=1; $packs = $db->FetchArray($sql); $j++)
{
?>	
                            <tr>
                                <td><?=$packs['id']?></td>
                                <td><?=$packs['days']?> days</td>
								<td><?=$packs['coins']?> coins</td>
								<td class="center">
									<a href="index.php?x=banners&edit=<?=$packs['id']?>" class="button small grey tooltip" data-gravity=s title="Edit"><i class="icon-pencil"></i></a>
									<a href="index.php?x=banners&del=<?=$packs['id']?>" class="button small grey tooltip" data-gravity=s title="Remove"><i class="icon-remove"></i></a>
								</td>
                            </tr>
<?}?>
                        </tbody>
                    </table>
				</div>
			</div>
		</section>
<?}else{?>
<section id="content" class="container_12 clearfix ui-sortable" data-sort=true>
	<h1 class="grid_12">Banners</h1>
	<div class="grid_12">
		<div class="box">
			<table class="styled">
				<thead>
					<tr>
						<th>ID</th>
						<th>User ID</th>
						<th>Banner</th>
						<th>Impressions</th>
						<th>Clicks</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
<?
$pagina = (isset($_GET['p']) ? $_GET['p'] : 0);
$limit = 20;
$start = (is_numeric($pagina) && $pagina > 0 ? ($pagina-1)*$limit : 0);

$sql = $db->Query("SELECT id FROM `banners`");
$total_pages = $db->GetNumRows($sql);
include('../system/libs/apaginate.php');

  $sql = $db->Query("SELECT * FROM `banners` ORDER BY `id` ASC LIMIT ".$start.",".$limit."");
  $pack = $db->FetchArrayAll($sql);
  foreach($pack as $packs){
?>	
					<tr>
						<td><?=$packs['id']?></td>
						<td><a href="index.php?x=users&edit=<?=$packs['user']?>"><?=$packs['user']?></a></td>
						<td><a href="<?=$packs['site_url']?>" title="<?=$packs['site_url']?>" target="_blank"><img src="<?=$packs['banner_url']?>" width="234" border="0" /></a></td>
						<td><?=number_format($packs['views'])?></td>
						<td><?=number_format($packs['clicks'])?></td>
						<td class="center">
							<a href="index.php?x=banners&b_edit=<?=$packs['id']?>" class="button small grey tooltip" data-gravity=s title="Edit"><i class="icon-pencil"></i></a>
							<a href="index.php?x=banners&b_del=<?=$packs['id']?>" class="button small grey tooltip" data-gravity=s title="Remove"><i class="icon-remove"></i></a>
						</td>
					</tr>
<?}?>
				</tbody>
			</table>
			<?if($total_pages > $limit){?>
			<div class="dataTables_wrapper">
			<div class="footer">
				<div class="dataTables_paginate paging_full_numbers">
					<a class="first paginate_button" href="index.php?x=<?=$_GET['x'].$pag_value?>&p=1">First</a>
					<?=(($pagina <= 1 || $pagina == '') ? '<a class="previous paginate_button">&laquo;</a>' : '<a class="previous paginate_button" href="index.php?x='.$_GET['x'].$pag_value.'&p='.($pagina-1).'">&laquo;</a>')?>
					<span>
						<?=$pagination?>
					</span>
					<?=(($pagina >= $lastpage) ? '<a class="next paginate_button">&raquo;</a>' : '<a class="next paginate_button" href="index.php?x='.$_GET['x'].$pag_value.'&p='.($pagina == 0 ? 2 : $pagina+1).'">&raquo;</a>')?>
					<a class="last paginate_button" href="index.php?x=<?=$_GET['x'].$pag_value?>&p=<?=$lastpage?>">Last</a>
				</div>
			</div>
			</div>
			<?}?>
		</div>
	</div>
</section>
<?}?>