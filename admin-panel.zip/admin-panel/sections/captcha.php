<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$mesaj = '';
if(isset($_POST['edit_captcha'])){
	$captcha_sys = $db->EscapeString($_POST['captcha_sys']);
	$captcha_sys = ($captcha_sys > 1 ? 1 : $captcha_sys < 0 ? 0 : $captcha_sys);
	$recaptcha_pub = $db->EscapeString($_POST['recaptcha_pub']);
	$recaptcha_sec = $db->EscapeString($_POST['recaptcha_sec']);
	
	if(!empty($recaptcha_pub) && !empty($recaptcha_sec)){
		$db->Query("UPDATE `settings` SET `captcha_sys`='".$captcha_sys."', `recaptcha_pub`='".$recaptcha_pub."', `recaptcha_sec`='".$recaptcha_sec."'");
		$mesaj = '<div class="alert success"><span class="icon"></span><strong>SUCCESS:</strong> Captcha settings successfully saved!</div>';
	}else{
		$mesaj = '<div class="alert error"><span class="icon"></span><strong>ERROR:</strong> Please complete all fields!</div>';
	}
}
?>
<section id="content" class="container_12"><?=$mesaj?>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Captcha Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Enable ReCaptcha</strong></label>
						<div><select name="captcha_sys"><option value="0">No</option><option value="1"<?=($site['captcha_sys'] == 1 ? ' selected' : '')?>>Yes</option></select></div>
					</div>
					<div class="row">
						<label><strong>ReCaptcha Public Key</strong></label>
						<div><input type="text" name="recaptcha_pub" value="<?=(isset($_POST['recaptcha_pub']) ? $_POST['recaptcha_pub'] : $site['recaptcha_pub'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>ReCaptcha Private Key</strong></label>
						<div><input type="text" name="recaptcha_sec" value="<?=(isset($_POST['recaptcha_sec']) ? $_POST['recaptcha_sec'] : $site['recaptcha_sec'])?>" required="required" /></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" name="edit_captcha" value="Submit" />
					</div>
				</div>
		</form>
	</div>
	<div class="grid_6">
		<div class="box">
			<div class="header">
				<h2>ReCaptcha Instrunctions</h2>
			</div>
				<div class="content">
					<p><b>1)</b> <a href="https://www.google.com/recaptcha/admin/create" target="_blank">Click Here</a>, complete on "Domain" with your domain name and click on "Create Key"</p>
					<p><b>2)</b> Copy generated "Public Key" and paste this key on "ReCaptcha Public Key"</p>
					<p><b>3)</b> Copy generated "Private Key" and paste this key on "ReCaptcha Private Key"</p>
					<p><b>4)</b> Press on "Submit" and you're done</p><br />
					<p><b>NOTE:</b> If you disable ReCaptcha, default system captcha will be used.</p>
                </div>
		</div>
	</div>
</section>