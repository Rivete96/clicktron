<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$users = $db->QueryGetNumRows("SELECT id FROM `users`");
$reg_today = $db->QueryGetNumRows("SELECT id FROM `users` WHERE DATE(`signup`)=CURDATE()");
$online = $db->QueryGetNumRows("SELECT id FROM `users` WHERE (".time()."-UNIX_TIMESTAMP(`online`)) < 3600");
$on_today = $db->QueryGetNumRows("SELECT id FROM `users` WHERE DATE(`online`) = DATE(NOW())");
$premium = $db->QueryGetNumRows("SELECT id FROM `users` WHERE `premium`>'0'");
$banned = $db->QueryGetNumRows("SELECT id FROM `users` WHERE `banned`='1'");
$coins = $db->QueryGetNumRows("SELECT id FROM `transactions` WHERE `type`='0'");
$vip = $db->QueryGetNumRows("SELECT id FROM `transactions` WHERE `type`='1'");
$reports = $db->QueryGetNumRows("SELECT id FROM `reports` WHERE `status`='0'");
$creports = $db->QueryGetNumRows("SELECT id FROM `reports` WHERE `status`!='0'");
$today_click = $db->QueryFetchArray("SELECT SUM(`today_clicks`) AS `today` FROM `user_clicks` WHERE `today_clicks`>'0'");
$waiting_sales = $db->QueryGetNumRows("SELECT id FROM `transactions` WHERE `paid`='0'");
if($site['paysys'] == 1){
	$waiting = $db->QueryGetNumRows("SELECT id FROM `requests` WHERE `paid`='0'");
	$paid = $db->QueryGetNumRows("SELECT id FROM `requests` WHERE `paid`='1'");
	$rejected = $db->QueryGetNumRows("SELECT id FROM `requests` WHERE `paid`='2'");
}

$total_coins = $db->QueryFetchArray("SELECT SUM(`coins`) AS `total` FROM `users`");
$total_vip = $db->QueryFetchArray("SELECT SUM(`premium`-'".time()."') AS `total` FROM `users` WHERE `premium`>'0'");
$total_vip = round(($total_vip['total']/86400), 0);

$total_income = $db->QueryFetchArray("SELECT SUM(money) AS money FROM transactions");
$total_income = (!empty($total_income['money']) ? $total_income['money'] : 0);
$income_month = $db->QueryFetchArray("SELECT SUM(money) AS money FROM transactions WHERE MONTH(date) = '".date('m')."'");
$income_month = (!empty($income_month['money']) ? $income_month['money'] : 0);
$income_today = $db->QueryFetchArray("SELECT SUM(money) AS money FROM transactions WHERE DATE(date) = DATE(NOW())");
$income_today = (!empty($income_today['money']) ? $income_today['money'] : 0);
?>
 		<section id="content" class="container_12 clearfix" data-sort=true>
			<ul class="stats not-on-phone">
				<li>
					<strong><?=number_format($users)?></strong>
					<small>Total Users</small>
					<span <?=($reg_today > 0 ? 'class="green" ' : '')?>style="margin:4px 0 -10px 0"><?=$reg_today?> today</span>
				</li>
				<li>
					<strong><?=number_format($on_today)?></strong>
					<small>Active Today</small>
				</li>
				<li>
					<strong><?=number_format($coins+$vip)?></strong>
					<small>Total Sales</small>
					<span <?=($waiting_sales > 0 ? 'class="green" ' : '')?>style="margin:4px 0 -10px 0"><?=$waiting_sales?> waiting</span>
				</li>
				<li>
					<strong><?=number_format(hook_filter('tot_sites',""))?></strong>
					<small>Total Pages</small>
				</li>
				<li>
					<strong><?=number_format(hook_filter('tot_clicks',""))?></strong>
					<small>Total Clicks</small>
					<span <?=($today_click['today'] > 0 ? 'class="green" ' : '')?>style="margin:4px 0 -10px 0"><?=number_format($today_click['today'])?> today</span>
				</li>
			</ul>

	

			<h1 class="grid_12 margin-top">Dashboard</h1>
			<div class="grid_12">
				<div class="box">
					<div class="header">
						<h2><img class="icon" src="img/icons/packs/fugue/16x16/users.png">Members statistics</h2>
					</div>
					<div class="content">
						<div class="spacer"></div>
						<div class="full-stats">
							<div class="stat hlist" data-list='[{"val":<?=$online?>,"title":"Online Members","color":"green"},{"val":<?=$premium?>,"title":"VIP Members"},{"val":<?=$banned?>,"title":"Banned Members","color":"red"},{"val":<?=$reg_today?>,"title":"Registered Today"},{"val":<?=$users?>,"title":"Total Members"}]' data-flexiwidth=true></div>
						</div>
					</div>
				</div>
			</div>
			<div class="grid_12">
				<div class="box">
					<div class="header">
						<h2><img class="icon" src="img/icons/packs/fugue/16x16/coins.png">Sales statistics</h2>
					</div>
					<div class="content">
						<div class="spacer"></div>
						<div class="full-stats">
							<div class="stat hlist" data-list='[{"val":<?=$income_today?>,"format":"<?=get_currency_symbol($site['currency_code'])?>0.00","title":"Today Income","color":"green"},{"val":<?=$income_month?>,"format":"<?=get_currency_symbol($site['currency_code'])?>0.00","title":"This Month"},{"val":<?=($total_income)?>,"format":"<?=get_currency_symbol($site['currency_code'])?>0.00","title":"Total Income","color":"red"}]' data-flexiwidth=true></div>
						</div>
					</div>
				</div>
			</div>
			<?if($site['paysys'] == 1){?>
			<div class="grid_12">
				<div class="box">
					<div class="header">
						<h2><img class="icon" src="img/icons/packs/fugue/16x16/orders.png">Payment Requests</h2>
					</div>
					<div class="content">
						<div class="spacer"></div>
						<div class="full-stats">
							<div class="stat hlist" data-list='[{"val":<?=$waiting?>,"format":"0","title":"Waiting"},{"val":<?=$paid?>,"format":"0","title":"Paid","color":"green"},{"val":<?=$rejected?>,"format":"0","title":"Rejected","color":"red"}]' data-flexiwidth=true></div>
						</div>
					</div>
				</div>
			</div>
			<?}?>
			<div class="grid_12">
				<div class="box">
					<div class="header">
						<h2><img class="icon" src="/img/report.png">Reports</h2>
					</div>
					<div class="content">
						<div class="spacer"></div>
						<div class="full-stats">
							<div class="stat hlist" data-list='[{"val":<?=$reports?>,"format":"0","title":"Waiting"},{"val":<?=$creports?>,"format":"0","title":"Checked","color":"green"}]' data-flexiwidth=true></div>
						</div>
					</div>
				</div>
			</div>
			<div class="grid_12">
				<div class="box">
					<div class="header">
						<h2><img class="icon" src="img/icons/packs/fugue/16x16/dashboard.png">Other Stats</h2>
					</div>
					<div class="content">
						<div class="spacer"></div>
						<div class="full-stats">
							<div class="stat hlist" data-list='[{"val":<?=$total_coins['total']?>,"format":"0,0","title":"Total Coins"},{"val":<?=$total_vip?>,"format":"0","title":"Total VIP Days","color":"green"}]' data-flexiwidth=true></div>
						</div>
					</div>
				</div>
			</div>
			<div class="grid_12">
				<div class="box">
					<div class="header">
						<h2><img class="icon" src="img/icons/packs/fugue/16x16/pages.png">Pages</h2>
					</div>
					<div class="content">
						<div class="spacer"></div>
						<?=hook_filter('admin_s_sites','')?>
				</div>
			</div>
		</section>