<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$mesaj = '';
if(isset($_POST['edit_paypal'])){
	$paypal = $db->EscapeString($_POST['paypal']);
	$paypal_status = ($_POST['paypal_status'] > 1 ? 1 : ($_POST['paypal_status'] < 0 ? 0 : $_POST['paypal_status']));
	$paypal_auto = ($_POST['paypal_auto'] > 1 ? 1 : ($_POST['paypal_auto'] < 0 ? 0 : $_POST['paypal_auto']));
	
	$db->Query("UPDATE `settings` SET `paypal`='".$paypal."', `paypal_status`='".$paypal_status."', `paypal_auto`='".$paypal_auto."'");
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
}
if(isset($_POST['edit_payza'])){
	$payza = $db->EscapeString($_POST['payza']);
	$payza_security = $db->EscapeString($_POST['payza_security']);
	$payza_status = ($_POST['payza_status'] > 1 ? 1 : ($_POST['payza_status'] < 0 ? 0 : $_POST['payza_status']));
	$payza_auto = ($_POST['payza_auto'] > 1 ? 1 : ($_POST['payza_auto'] < 0 ? 0 : $_POST['payza_auto']));
	
	$db->Query("UPDATE `settings` SET `payza`='".$payza."', `payza_security`='".$payza_security."', `payza_status`='".$payza_status."', `payza_auto`='".$payza_auto."'");
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
}
?>
<section id="content" class="container_12"><?=$mesaj?>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Paypal</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Paypal Email</strong></label>
						<div><input type="text" name="paypal" value="<?=(isset($_POST['paypal']) ? $_POST['paypal'] : $site['paypal'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Add Funds</strong><small>If set "Manually", you have to<br />approve each transaction.</small></label>
						<div><select name="paypal_auto"><option value="0">Manually</option><option value="1"<?=($site['paypal_auto'] == 1 || isset($_POST['paypal_auto']) && $_POST['paypal_auto'] == 1 ? ' selected' : '')?>>Automatically</option></select></div>
					</div>
					<div class="row">
						<label><strong>Status</strong></label>
						<div><select name="paypal_status"><option value="0">Disabled</option><option value="1"<?=($site['paypal_status'] == 1 || isset($_POST['paypal_status']) && $_POST['paypal_status'] == 1 ? ' selected' : '')?>>Enabled</option></select></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" name="edit_paypal" value="Submit" />
					</div>
				</div>
		</form>
	</div>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Payza</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Payza Email</strong></label>
						<div><input type="text" name="payza" value="<?=(isset($_POST['payza']) ? $_POST['payza'] : $site['payza'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>IPN Security Code</strong></label>
						<div><input type="text" name="payza_security" value="<?=(isset($_POST['payza_security']) ? $_POST['payza_security'] : $site['payza_security'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Add Funds</strong><small>If set "Manually", you have to<br />approve each transaction.</small></label>
						<div><select name="payza_auto"><option value="0">Manually</option><option value="1"<?=($site['payza_auto'] == 1 || isset($_POST['payza_auto']) && $_POST['payza_auto'] == 1 ? ' selected' : '')?>>Automatically</option></select></div>
					</div>
					<div class="row">
						<label><strong>Status</strong></label>
						<div><select name="payza_status"><option value="0">Disabled</option><option value="1"<?=($site['payza_status'] == 1 || isset($_POST['payza_status']) && $_POST['payza_status'] == 1 ? ' selected' : '')?>>Enabled</option></select></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" name="edit_payza" value="Submit" />
					</div>
				</div>
		</form>
	</div>
</section>
<section id="content" class="container_12 clearfix">
	<div class="grid_6">
		<div class="box">
			<div class="header">
				<h2>Paypal Instrunctions</h2>
			</div>
				<div class="content">
					<p><b>PayPal Email</b> = Here you have to add your PayPal email</p>
					<p><b>PayPal Status</b> = Enable or Disable this payment gateway</p>
                </div>
		</div>
	</div>
	<div class="grid_6">
		<div class="box">
			<div class="header">
				<h2>Payza Instrunctions</h2>
			</div>
				<div class="content">
					<p>1) Login on your Payza account, go to <i>Manage Business Profiles</i> -> <i>Add</i> and create an business profile for your website</p>
					<p>2) Go to <i>Manage websites</i> -> <i>Add Website</i> and submit your website for review</p>
					<p>3) After your website was approved by Payza, go  tp <i>IPN Advanced Integration</i> -> <i>IPN Setup</i>, write your Transaction PIN and click <i>Access</i>
					<p>4) Click on <i>Edit</i>, in row with your business profile created at step 1, and complete with:
						<ul>
							<li><b>IPN Status</b> = Enabled</li>
							<li><b>Enable IPN Version 2</b> = Disabled</li>
							<li><b>Allow Encrypted Payment Details</b> = Disabled</li>
							<li><b>Alert URL:</b><br>
							<input type="text" value="<?=$site['site_url']?>/system/payments/payza/ipn.php" onclick="this.select()" style="width:300px" /></li>
							<li><b>Test Mode</b> = Disabled</li>
						</ul>
					</p>
					<p> 5) Come back here and complete <i>Payza Email</i> with your payza business email selected at step 1 and <i>IPN Security Code</i> with code from <i>IPN Setup</i> -> <i>IPN Security Code</i>
				</div>
		</div>
	</div>
</section>