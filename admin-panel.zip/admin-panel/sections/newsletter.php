<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$n1 = rand(1,9);
$n2 = rand(1,9);
?>
<script type="text/javascript">
	var start = 0;
	var limit = 50;
	var interval = 20;
	var eTotal = 0;
	var secode = '<?=($n1+$n2)?>';
	var captcha = 0;
	var receivers = 0;
	var title = '';
	var message = '';
	function send(){
		captcha = document.getElementById("captcha").value;
		limit = document.getElementById("batches").value;
		receivers = document.getElementById("receivers").value;
		title = document.getElementById("title").value;
		message = document.getElementById("message").value;
		get_total();
		process();
	}
	function get_total() {
		$("#Hint").html("<div class=\"alert information\">Please wait...</div>");
		$.ajax({
			type: "POST", 
			url: "sections/inc/sendemails.php", 
			data: "get=1&receivers="+receivers, 
			success: function (a) {
				eTotal = a;
			}
		});
	}
	function process() {
		$.ajax({
			type: "POST", 
			url: "sections/inc/sendemails.php", 
			data: "start="+start+"&limit="+limit+"&title="+title+"&message="+message+"&captcha="+captcha+"&secode="+secode+"&receivers="+receivers, 
			success: function (a) {
				if (a == 'DONE') {
					start = 0;
					$("#Hint").html("<div class=\"alert success\">"+eTotal+" emails were successfully sent!</div>");
				} else if (a == 'CAPTCHA_ERROR') {
					$("#Hint").html("<div class=\"alert error\"><strong>ERROR!</strong> Security answer is wrong!</div>");
				} else if (a == 'FIELDS_ERROR') {
					$("#Hint").html("<div class=\"alert error\"><strong>ERROR!</strong> Please complete all fields!</div>");
				} else if (!isNaN(a)) {
					start = a;
					$("#Hint").html("<div class=\"alert information\">Sending emails " + start + " / "+eTotal+". Please wait...</div>");
					b = setTimeout(function () {process();}, (interval*100));
				}
			}
		});
	}
</script>
<section id="content" class="container_12 clearfix">
	<div class="grid_12" id="Hint"></div>
	<div class="grid_8">
		<form name="news" action="javascript:send()" class="box">
			<div class="header">
				<h2>Send Newsletter</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>To</strong></label>
						<div><select style="width:350px" name="receivers" id="receivers"><option value="0">All users</option><option value="3">Subscribed to Newsletter</option><option value="1">Users active in past 7 days</option><option value="2">Users inactive in past 7 days</option></select></div>
					</div>
					<div class="row">
						<label><strong>Batches of emails</strong></label>
						<div><select style="width:350px" name="batches" id="batches"><option value="25">25</option><option value="50" selected="selected">50</option><option value="100">100</option><option value="150">150</option><option value="200">200</option></select></div>
					</div>
					<div class="row">
						<label><strong>Subject</strong></label>
						<div><input style="width:360px" type="text" name="title" id="title" maxlength="60" value="<?=(isset($_POST['title']) ? $_POST['title'] : '')?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Message</strong></label>
						<div><textarea style="width:360px" name="message" id="message" rows="6" required="required"><?=(isset($_POST['message']) ? $_POST['message'] : '')?></textarea></div>
					</div>
					<div class="row">
						<label><strong><?=($n1." + ".$n2." = ?")?></strong></label>
						<div><input style="width:360px" type="text" name="captcha" id="captcha" required="required" /></div>
					</div>										
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" />
					</div>
				</div>
		</form>
	</div>
		<div class="grid_4">
		<div class="box">
			<div class="header">
				<h2>Info</h2>
			</div>
            <div class="content"><br />
				<p>Here you can send emails to all members registered on this website!</p>
				<p>If you want to include usernames in email, you can use -USER-<br />
				E.g: <b>Hello -USER-!</b> will be <b>Hello Username!</b></p>
				<p>Also, all emails are sent in HTML format, so you can use following BB Code tags:
				<ul>
					<li>[b]text[/b] => <b>text</b></li>
					<li>[u]text[/u] => <u>text</u></li>
					<li>[i]text[/i] => <i>text</i></li>
					<li>[code]text[/code] => <code>text</code></li>
					<li>[url=http://url.com]text[/url] => <a href="#">text</a></li>
				</ul>
				</p>
            </div>
		</div>
	</div>
</section>