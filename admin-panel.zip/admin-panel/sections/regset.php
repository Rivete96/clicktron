<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$mesaj = '';
if(isset($_POST['submit'])){
	$more_per_ip = $db->EscapeString($_POST['more_per_ip']);
	$reg_reqmail = $db->EscapeString($_POST['reg_reqmail']);
	$reg_status = $db->EscapeString($_POST['reg_status']);
	$auto_country = ($_POST['auto_country'] > 1 ? 1 : ($_POST['auto_country'] < 0 ? 0 : $_POST['auto_country']));
	
	$settings_post = hook_filter('admin_settings_post',"");
	if($hideref == 2 && empty($revshare_api)){
		$mesaj = '<div class="alert error"><span class="icon"></span><strong>ERROR:</strong> If you want to use RevShare anonymous referring, RevShare API is required!</div>';
	}else{
		$db->Query("UPDATE `settings` SET `reg_status`='".$reg_status."', `reg_reqmail`='".$reg_reqmail."', `more_per_ip`='".$more_per_ip."', `auto_country`='".$auto_country."'");
		$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
	}
}
if(isset($_POST['usubmit'])){
	$reg_coins = $db->EscapeString($_POST['reg_coins']);
	$reg_cash = $db->EscapeString($_POST['reg_cash']);
	$db->Query("UPDATE `settings` SET `reg_coins`='".$reg_coins."', `reg_cash`='".$reg_cash."'");
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
}
?>
<section id="content" class="container_12 clearfix"><?=$mesaj?>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>General Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Registration</strong></label>
						<div><select name="reg_status"><option value="0">Enabled</option><option value="1"<?=($site['reg_status'] != 0 ? ' selected' : '')?>>Disabled</option></select></div>
					</div>
					<div class="row">
						<label><strong>Auto-Select country</strong><small>Prevents selecting fake countries at registration</small></label>
						<div><select name="auto_country"><option value="0">Disabled</option><option value="1"<?=($site['auto_country'] == 1 ? ' selected' : '')?>>Enabled</option></select></div>
					</div>
					<div class="row">
						<label><strong>1 account per IP</strong></label>
						<div><select name="more_per_ip"><option value="0">Yes</option><option value="1"<?=($site['more_per_ip'] != 0 ? ' selected' : '')?>>No</option></select></div>
					</div>
					<div class="row">
						<label><strong>Email Confirmation</strong></label>
						<div><select name="reg_reqmail"><option value="0">Enabled</option><option value="1"<?=($site['reg_reqmail'] != 0 ? ' selected' : '')?>>Disabled</option></select></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="submit" />
					</div>
				</div>
		</form>
	</div>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Other Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Coins on Signup</strong><small>Coins added after registration</small></label>
						<div><input type="text" name="reg_coins" value="<?=(isset($_POST['reg_coins']) ? $_POST['reg_coins'] : $site['reg_coins'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Cash on Signup</strong><small>Money added after registration</small></label>
						<div><input type="text" name="reg_cash" value="<?=(isset($_POST['reg_cash']) ? $_POST['reg_cash'] : $site['reg_cash'])?>" required="required" /></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="usubmit" />
					</div>
				</div>
		</form>
	</div>
</section>