<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$mesaj = '';
if(isset($_POST['submit'])){
	$name = $db->EscapeString($_POST['name']);
	$description = $db->EscapeString($_POST['description']);
	$url = $db->EscapeString($_POST['url']);
	$email = $db->EscapeString($_POST['email']);
	$mode = $db->EscapeString($_POST['mode']);
	$progress = $db->EscapeString($_POST['progress']);
	$m_twitter = $db->EscapeString($_POST['m_twitter']);
	$fb_fan_url = $db->EscapeString($_POST['fb_fan_url']);
	$def_lang = $db->EscapeString($_POST['def_lang']);
	$mysql_random = ($_POST['mysql_random'] > 1 ? 1 : ($_POST['mysql_random'] < 0 ? 0 : $_POST['mysql_random']));
	$report_limit = ($_POST['report_limit'] < 0 ? 0 : $_POST['report_limit']);
	$hideref = ($_POST['hideref'] > 2 ? 2 : ($_POST['hideref'] < 0 ? 0 : $_POST['hideref']));
	$revshare_api = $db->EscapeString($_POST['revshare_api']);
	$target_system = ($_POST['target_system'] > 2 ? 2 : ($_POST['target_system'] < 0 ? 0 : $_POST['target_system']));
	
	$settings_post = hook_filter('admin_settings_post',"");
	if($hideref == 2 && empty($revshare_api)){
		$mesaj = '<div class="alert error"><span class="icon"></span><strong>ERROR:</strong> If you want to use RevShare anonymous referring, RevShare API is required!</div>';
	}else{
		$db->Query("UPDATE `settings` SET `site_name`='".$name."', `site_description`='".$description."', `site_url`='".$url."', `site_email`='".$email."', `maintenance`='".$mode."', `m_progress`='".$progress."', `m_twitter`='".$m_twitter."', `fb_fan_url`='".$fb_fan_url."', `def_lang`='".$def_lang."', `hideref`='".$hideref."', `target_system`='".$target_system."', `report_limit`='".$report_limit."', `mysql_random`='".$mysql_random."', `revshare_api`='".$revshare_api."'".$settings_post);
		$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
	}
}
if(isset($_POST['usubmit'])){
	$analytics_id = $db->EscapeString($_POST['analytics_id']);
	$free_cpc = $db->EscapeString($_POST['free_cpc']);
	$premium_cpc = $db->EscapeString($_POST['premium_cpc']);
	$daily_bonus = $db->EscapeString($_POST['daily_bonus']);
	$daily_bonus_vip = $db->EscapeString($_POST['daily_bonus_vip']);
	$crf_bonus = $db->EscapeString($_POST['crf_bonus']);
	$youtube_api = $db->EscapeString($_POST['youtube_api']);
	$transfer_status = $db->EscapeString($_POST['transfer_status']);
	$banner_status = $db->EscapeString($_POST['banner_status']);
	$c_c_limit = $db->EscapeString($_POST['c_c_limit']);
	$c_v_limit = $db->EscapeString($_POST['c_v_limit']);
	$blog_comments = $db->EscapeString($_POST['blog_comments']);
	$transfer_fee = ($_POST['transfer_fee'] > 100 ? 100 : ($_POST['transfer_fee'] < 0 ? 0 : $_POST['transfer_fee']));
	$settings_upost = hook_filter('admin_u_settings_post',"");
	
	$db->Query("UPDATE `settings` SET `free_cpc`='".$free_cpc."', `premium_cpc`='".$premium_cpc."', `daily_bonus`='".$daily_bonus."', `daily_bonus_vip`='".$daily_bonus_vip."', `crf_bonus`='".$crf_bonus."', `youtube_api`='".$youtube_api."', `transfer_status`='".$transfer_status."', `transfer_fee`='".$transfer_fee."', `banner_system`='".$banner_status."', `c_c_limit`='".$c_c_limit."', `c_v_limit`='".$c_v_limit."', `analytics_id`='".$analytics_id."', `blog_comments`='".$blog_comments."'".$settings_upost);
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
}
?>
<section id="content" class="container_12 clearfix"><?=$mesaj?>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>General Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Site Title</strong></label>
						<div><input type="text" name="name" value="<?=(isset($_POST['name']) ? $_POST['name'] : $site['site_name'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Site Description</strong></label>
						<div><textarea name="description" required="required"><?=(isset($_POST['description']) ? $_POST['description'] : $site['site_description'])?></textarea></div>
					</div>
					<div class="row">
						<label><strong>Site URL</strong><small>Without trailing slash</small></label>
						<div><input type="text" name="url" value="<?=(isset($_POST['url']) ? $_POST['url'] : $site['site_url'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Contact Email</strong></label>
						<div><input type="email" name="email" value="<?=(isset($_POST['email']) ? $_POST['email'] : $site['site_email'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Default Language</strong></label>
						<div><select name="def_lang"><?foreach(glob("../languages/*/index.php") as $langname){include_once($langname); if($c_lang['active'] != 0){ $selected = (isset($_POST['def_lang']) && $_POST['def_lang'] == $c_lang['code'] ? ' selected' : ($site['def_lang'] == $c_lang['code'] ? ' selected' : '')); echo '<option value="'.$c_lang['code'].'"'.$selected.'>'.$c_lang['lang'].'</option>';}}?></select></div>
					</div>
					<div class="row">
						<label><strong>Maintenance Mode</strong></label>
						<div><select name="mode"><option value="0">Inactive</option><option value="1"<?=($site['maintenance'] != 0 ? ' selected' : '')?>>Active</option></select></div>
					</div>	
					<div class="row">
						<label><strong>Progress (%)</strong><small>Maintenance Progress</small></label>
						<div><input type="text" name="progress" value="<?=(isset($_POST['progress']) ? $_POST['progress'] : $site['m_progress'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>FB Fanpage Username</strong></label>
						<div><input type="text" name="fb_fan_url" value="<?=(isset($_POST['fb_fan_url']) ? $_POST['fb_fan_url'] : $site['fb_fan_url'])?>" /></div>
					</div>
					<div class="row">
						<label><strong>Twitter Username</strong></label>
						<div><input type="text" name="m_twitter" value="<?=(isset($_POST['m_twitter']) ? $_POST['m_twitter'] : $site['m_twitter'])?>" /></div>
					</div>
					<div class="row">
						<label><strong>Anonymous referring</strong></label>
						<div><select name="hideref"><option value="0">Disabled</option><option value="1"<?=($site['hideref'] == 1 ? ' selected' : '')?>>Anonym.to</option></select></div>
					</div>
					<div class="row">
						<label><strong>RevShare API Key</strong><small><a href="#" target="_blank">Developer Website nulled</a></small></label>
						<div><input type="text" name="revshare_api" value="<?=(isset($_POST['revshare_api']) ? $_POST['revshare_api'] : $site['revshare_api'])?>"  placeholder="Nulled" disabled/></div>
					</div>
					<div class="row">
						<label><strong>Targeting System</strong><small>Clicks based on Countries & Genders</small></label>
						<div><select name="target_system"><option value="0">Enabled</option><option value="2"<?=($site['target_system'] == 2 ? ' selected' : '')?>>Disabled</option><option value="1"<?=($site['target_system'] == 1 ? ' selected' : '')?>>VIP Only</option></select></div>
					</div>
					<div class="row">
						<label><strong>Active Reports Limit</strong><small>Set 0 to disable</small></label>
						<div><input type="text" name="report_limit" value="<?=(isset($_POST['report_limit']) ? $_POST['report_limit'] : $site['report_limit'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Randomize Module Results</strong><small>Will increase your server usage</small></label>
						<div><select name="mysql_random"><option value="0">Disabled</option><option value="1"<?=($site['mysql_random'] == 1 ? ' selected' : '')?>>Enabled</option></select></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="submit" />
					</div>
				</div>
		</form>
	</div>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Other Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Max CPC (free users)</strong></label>
						<div><input type="text" name="free_cpc" value="<?=(isset($_POST['free_cpc']) ? $_POST['free_cpc'] : $site['free_cpc'])?>" maxlength="3" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Max CPC (vip users)</strong></label>
						<div><input type="text" name="premium_cpc" value="<?=(isset($_POST['premium_cpc']) ? $_POST['premium_cpc'] : $site['premium_cpc'])?>" maxlength="3" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Daily Bonus (free users)</strong></label>
						<div><input type="text" name="daily_bonus" value="<?=(isset($_POST['daily_bonus']) ? $_POST['daily_bonus'] : $site['daily_bonus'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Daily Bonus (vip users)</strong></label>
						<div><input type="text" name="daily_bonus_vip" value="<?=(isset($_POST['daily_bonus_vip']) ? $_POST['daily_bonus_vip'] : $site['daily_bonus_vip'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Clicks for Bonus</strong></label>
						<div><input type="text" name="crf_bonus" value="<?=(isset($_POST['crf_bonus']) ? $_POST['crf_bonus'] : $site['crf_bonus'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Enable Blog Comments</strong></label>
						<div><select name="blog_comments"><option value="0">Disabled</option><option value="1"<?=($site['blog_comments'] == 1 ? ' selected' : '')?>>Enabled</option></select></div>
					</div>
					<div class="row">
						<label><strong>Change info limit (free)</strong></label>
						<div><input type="text" name="c_c_limit" value="<?=(isset($_POST['c_c_limit']) ? $_POST['c_c_limit'] : $site['c_c_limit'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Change info limit (vip)</strong></label>
						<div><input type="text" name="c_v_limit" value="<?=(isset($_POST['c_v_limit']) ? $_POST['c_v_limit'] : $site['c_v_limit'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Youtube API</strong><small>(<a href="https://code.google.com/apis/youtube/dashboard/gwt/index.html"target="_blank">click here</a>)</small></label>
						<div><input type="text" name="youtube_api" value="<?=(isset($_POST['youtube_api']) ? $_POST['youtube_api'] : $site['youtube_api'])?>" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Banner Ads System</strong></label>
						<div><select name="banner_status"><option value="0">Disabled</option><option value="1"<?=($site['banner_system'] == 1 ? ' selected' : '')?>>Enabled</option><option value="2"<?=($site['banner_system'] == 2 ? ' selected' : '')?>>Only for VIP</option></select></div>
					</div>
					<div class="row">
						<label><strong>Transfer Coins</strong></label>
						<div><select name="transfer_status"><option value="0">Enabled</option><option value="1"<?=($site['transfer_status'] == 1 ? ' selected' : '')?>>Disabled</option><option value="2"<?=($site['transfer_status'] == 2 ? ' selected' : '')?>>Only for VIP</option></select></div>
					</div>
					<div class="row">
						<label><strong>Transfer Fee (xx %)</strong></label>
						<div><input type="text" name="transfer_fee" value="<?=(isset($_POST['transfer_fee']) ? $_POST['transfer_fee'] : $site['transfer_fee'])?>" maxlength="3" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Analytics ID</strong><small>Google Analytics tracking ID</small></label>
						<div><input type="text" name="analytics_id" value="<?=(isset($_POST['analytics_id']) ? $_POST['analytics_id'] : $site['analytics_id'])?>" placeholder="Leave blank to disable!" /></div>
					</div>
					<?=hook_filter('admin_u_settings',"")?>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="usubmit" />
					</div>
				</div>
		</form>
	</div>
</section>