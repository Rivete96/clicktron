<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
if(!mysql_query("SELECT refsys FROM settings")){executeSql("refdb.sql");}

$mesaj = '';
if(isset($_POST['submit'])){
	$surf_time = $db->EscapeString($_POST['surf_time']);
	$surf_type = $db->EscapeString($_POST['surf_type']);
	$surf_time_type = $db->EscapeString($_POST['surf_time_type']);
	$db->Query("UPDATE `settings` SET `surf_time`='".$surf_time."', `surf_time_type`='".$surf_time_type."', `surf_type`='".$surf_type."'");
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully updated!</div>';
}
if(isset($_POST['usubmit'])){
	$surf_fb_skip = $db->EscapeString($_POST['surf_fb_skip']);
	$surf_fc_req = $db->EscapeString($_POST['surf_fc_req']);
	$db->Query("UPDATE `settings` SET `surf_fb_skip`='".$surf_fb_skip."', `surf_fc_req`='".$surf_fc_req."'");
	$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully updated!</div>';
}
?>
<section id="content" class="container_12 clearfix"><?=$mesaj?>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>General Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Time Type</strong><small>If you select "Based on CPC",<br />time will be CPC x Time</small></label>
						<div><select name="surf_time_type"><option value="0">Fixed Time</option><option value="1"<?=($site['surf_time_type'] == 1 && !isset($_POST['surf_time_type']) ? ' selected' : (isset($_POST['surf_time_type']) && $_POST['surf_time_type'] == 1 ? ' selected' : ''))?>>Based on CPC</option></select></div>
					</div>
					<div class="row">
						<label><strong>Traffic Exchange time</strong></label>
						<div><input type="text" name="surf_time" value="<?=(isset($_POST['surf_time']) ? $_POST['surf_time'] : $site['surf_time'])?>" title="How many seconds?" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>Traffic Exchange type</strong></label>
						<div><select name="surf_type"><option value="0">Auto-Surf</option><option value="1"<?=($site['surf_type'] == 1 && !isset($_POST['surf_type']) ? ' selected' : (isset($_POST['surf_type']) && $_POST['surf_type'] == 1 ? ' selected' : ''))?>>Manual-Surf</option><option value="2"<?=($site['surf_type'] == 2 && !isset($_POST['surf_type']) ? ' selected' : (isset($_POST['surf_type']) && $_POST['surf_type'] == 2 ? ' selected' : ''))?>>Popup-Surf</option></select></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="submit" />
					</div>
				</div>
		</form>
	</div>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Other Settings</h2>
			</div>
				<div class="content">
					<div class="row">
						<label><strong>Skip pages with frame breaker</strong><small>Not applicable for "Popup-Surf"</small></label>
						<div><select name="surf_fb_skip"><option value="0">No</option><option value="1"<?=($site['surf_fb_skip'] == 1 && !isset($_POST['surf_fb_skip']) ? ' selected' : (isset($_POST['surf_fb_skip']) && $_POST['surf_fb_skip'] == 1 ? ' selected' : ''))?>>Yes</option></select></div>
					</div>
					<div class="row">
						<label><strong>Focus window required</strong><small>Not applicable for "Popup-Surf"</small></label>
						<div><select name="surf_fc_req"><option value="0">No</option><option value="1"<?=($site['surf_fc_req'] == 1 && !isset($_POST['surf_fc_req']) ? ' selected' : (isset($_POST['surf_fc_req']) && $_POST['surf_fc_req'] == 1 ? ' selected' : ''))?>>Yes</option></select></div>
					</div>
                </div>
				<div class="actions">
					<div class="right">
						<input type="submit" value="Submit" name="usubmit" />
					</div>
				</div>
		</form>
	</div>
</section>