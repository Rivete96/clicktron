<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['fbp_01'] = '<b>ERROR:</b> That photo cannot be added! We accept only fanpage photos!';
$lang['fbp_02'] = 'Photo was successfully added!';
$lang['fbp_03'] = 'SUCCESS! You skipped this photo!';
$lang['fbp_04'] = 'SUCCESS! You have received <b>-NUM- coins</b>!';
$lang['fbp_05'] = 'Photo already added!';
$lang['fbp_06'] = 'ERROR! You have to be logged in to receive coins!';
$lang['fbp_07'] = 'Like photo and close opened window...';
$lang['fbp_08'] = 'We cannot contact facebook...';
$lang['fbp_09'] = 'Facebook says you haven\'t liked this photo!';
$lang['fbp_10'] = 'SUCCESS!';
$lang['fbp_11'] = ' <b>coins</b> were added to your account!';
$lang['fbp_12'] = 'Like';
$lang['fbp_13'] = 'URL must be something like: http://www.facebook.com/photo.php?fbid=<b>PHOTO-ID</b>';
$lang['fbp_14'] = 'skip';

// Add Page
$lang['fbp_url'] = 'Facebook Photo URL';
$lang['fbp_title'] = 'Title';
$lang['fbp_url_desc'] = 'Enter facebook photo URL';
$lang['fbp_title_desc'] = 'Add your page title here';
?>