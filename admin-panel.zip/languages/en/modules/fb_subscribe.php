<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['fbs_01'] = '<b>ERROR:</b> Your facebook account\'s subscription is turned off, please turn it on and try again.';
$lang['fbs_02'] = 'Profile successfully added!';
$lang['fbs_03'] = 'SUCCESS! You skipped this profile!';
$lang['fbs_04'] = 'SUCCESS! You have received <b>-NUM- coins</b>!';
$lang['fbs_05'] = 'Profile already added!';
$lang['fbs_06'] = 'ERROR! You have to be logged in to receive coins!';
$lang['fbs_07'] = 'Follow to this user and close opened window...';
$lang['fbs_08'] = 'We cannot contact facebook...';
$lang['fbs_09'] = 'Facebook says you haven\'t subscribed to this profile!';
$lang['fbs_10'] = 'SUCCESS!';
$lang['fbs_11'] = ' <b>coins</b> were added to your account!';
$lang['fbs_12'] = 'Follow';
$lang['fbs_13'] = '<b>ERROR:</b> This facebook profile doesn\'t exists!';
$lang['fbs_14'] = 'skip';

// Add Page
$lang['fbs_url'] = 'Username / ID';
$lang['fbs_url_desc'] = 'Type your facebook username or id';
?>