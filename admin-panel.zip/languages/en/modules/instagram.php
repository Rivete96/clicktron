<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['ins_01'] = 'URL must be something like: http://instagram.com/<b>USERNAME</b>';
$lang['ins_02'] = 'Profile already added!';
$lang['ins_03'] = 'This instagram profile doesn\'t exists!';
$lang['ins_04'] = 'Profile was successfully added!';
$lang['ins_05'] = 'Follow';
$lang['ins_06'] = 'Confirm';
$lang['ins_07'] = 'skip';
$lang['ins_08'] = 'Follow user and close opened window...';
$lang['ins_09'] = 'We cannot contact instagram...';
$lang['ins_10'] = 'SUCCESS!';
$lang['ins_11'] = ' coins were added to your account!';
$lang['ins_12'] = 'Instagram says you aren\'t following this user!';
$lang['ins_13'] = 'SUCCESS! You skipped this user!';

// Add Page
$lang['ins_url'] = 'Profile URL';
$lang['ins_url_desc'] = 'Add your profile url here';
?>