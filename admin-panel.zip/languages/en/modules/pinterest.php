<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['pin_01'] = 'URL must be something like: http://pinterest.com/<b>USERNAME</b>';
$lang['pin_02'] = 'Profile already added!';
$lang['pin_03'] = 'This pinterest profile doesn\'t exists!';
$lang['pin_04'] = 'Profile was successfully added!';
$lang['pin_05'] = 'Follow';
$lang['pin_06'] = 'Confirm';
$lang['pin_07'] = 'skip';
$lang['pin_08'] = 'Follow user and close opened window...';
$lang['pin_09'] = 'We cannot contact pinterest...';
$lang['pin_10'] = 'SUCCESS!';
$lang['pin_11'] = ' coins were added to your account!';
$lang['pin_12'] = 'Pinterest says you aren\'t following this user!';
$lang['pin_13'] = 'SUCCESS! You skipped this user!';

// Add Page
$lang['pin_url'] = 'Profile URL';
$lang['pin_url_desc'] = 'Add your profile url here';
?>