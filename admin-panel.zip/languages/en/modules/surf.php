<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['surf_01'] = 'Website already added!';
$lang['surf_02'] = 'Site confirmed with success!';
$lang['surf_03'] = 'Site already confirmed!';
$lang['surf_04'] = 'Visit';
$lang['surf_05'] = 'skip';
$lang['surf_06'] = 'SUCCESS! You skipped this page!';
$lang['surf_07'] = 'You already visited this page!';
$lang['surf_08'] = '<b>SUCCESS!</b><br> You have received <b>-NUM- coins</b>!';
$lang['surf_09'] = 'You will receive';
$lang['surf_10'] = 'Start Traffic Exchange';
$lang['surf_11'] = 'Stop Traffic Exchange';
$lang['surf_12'] = 'Please keep window opened to receive coins!';
$lang['surf_13'] = 'Click on "Start Traffic Exchange" button and allow popup opened.';
$lang['surf_14'] = 'Website was successfully added!';

// Add Page
$lang['surf_url'] = 'URL';
$lang['surf_title'] = 'Title';
$lang['surf_url_desc'] = 'Add your url here';
$lang['surf_title_desc'] = 'Add your page title here';
?>