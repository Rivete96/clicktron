<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['twt_01'] = 'Youtube Video ID';
$lang['twt_02'] = 'Youtube Video ID';
$lang['twt_03'] = 'Youtube Video ID already exist!';
$lang['twt_04'] = 'Youtube Video ID successfully added!';
$lang['twt_05'] = 'Youtube says';
$lang['twt_06'] = 'Youtube Video doesn\'t exist!';
$lang['twt_07'] = 'CPC successfully changed!';
$lang['twt_08'] = 'Change CPC';
$lang['twt_09'] = 'Youtube Video';
$lang['twt_10'] = 'Youtube Video ID Just XXXXXXXXXXX';
$lang['twt_11'] = 'Press "Comment" on this page and after that say some good comment and press "Post". After that close opened window.';
$lang['twt_12'] = 'Comment';
$lang['twt_13'] = 'Comment Video and after that close window!';
$lang['twt_14'] = 'skip';
$lang['twt_15'] = 'Add your Youtube Video ID first!';
$lang['twt_16'] = 'SUCCESS! You skipped this Video!';
$lang['twt_17'] = 'Youtube says you aren\'t Comment this Video!';
$lang['twt_18'] = 'SUCCESS!';
$lang['twt_19'] = ' coins were added to your account!';
?>