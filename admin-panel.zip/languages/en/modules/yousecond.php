<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['ys_01'] = 'This YouSecond profile cannot be added!';
$lang['ys_02'] = 'Profile already added!';
$lang['ys_03'] = 'This YouSecond profile doesn\'t exists!';
$lang['ys_04'] = 'Profile was successfully added!';
$lang['ys_05'] = 'Friend';
$lang['ys_06'] = 'Confirm';
$lang['ys_07'] = 'skip';
$lang['ys_08'] = 'Send friend request and close opened window...';
$lang['ys_09'] = 'We cannot contact YouSecond...';
$lang['ys_10'] = 'SUCCESS!';
$lang['ys_11'] = ' coins were added to your account!';
$lang['ys_12'] = 'YouSecond says you haven\'t sent friend request!';
$lang['ys_13'] = 'SUCCESS! You skipped this user!';

// Add Page
$lang['ys_url'] = 'Username';
$lang['ys_url_desc'] = 'Add your YouSecond username here';
?>