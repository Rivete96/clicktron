<?
define('BASEPATH', true);
include('config.php');
if(isset($_POST['get'])) {
	$sql = $db->Query("SELECT SUM(`today_clicks`) AS `clicks` FROM `user_clicks` WHERE `uid`='".$data['id']."'");
	$cf_bonus = $db->FetchArray($sql);
	if($cf_bonus['clicks'] > 0){
		$cf_bonus = $cf_bonus['clicks'];
	}else{
		$cf_bonus = 0;
	}
	
	if($data['id'] != '' && ($data['daily_bonus']+86400) < time() && $cf_bonus >= $site['crf_bonus']){
		$bonus_c = ($data['premium'] > 0 ? $site['daily_bonus_vip'] : $site['daily_bonus']);
		$db->Query("UPDATE `users` SET `coins`=`coins`+'".$bonus_c."', `daily_bonus`='".time()."' WHERE `id`='".$data['id']."'");
		echo '1';
	}else{
		echo '0';
	}
}
?>