<?php
$config['sql_host']      = 'localhost';
$config['sql_username']  = 'tronixnf_admin';		// Database Username
$config['sql_password']  = 'RMF93Is[O41@';		// Database Password
$config['sql_database']  = 'tronixnf_add';		// The database
?>