<?php
if(!mysql_query("SELECT banner_system FROM settings")){$db->Query("ALTER TABLE `settings` ADD `banner_system` INT( 11 ) NOT NULL DEFAULT '1'");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'banners'"))){executeSql("system/modules/banners/sql.sql");}
?>