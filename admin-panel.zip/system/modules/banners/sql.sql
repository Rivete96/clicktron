CREATE TABLE IF NOT EXISTS `banners` (
  `id` int(255) NOT NULL auto_increment,
  `user` int(255) NOT NULL default '0',
  `banner_url` varchar(255) NOT NULL,
  `site_url` varchar(255) NOT NULL,
  `views` int(255) NOT NULL default '0',
  `clicks` int(255) NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `expiration` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `banner_packs` (
  `id` int(255) NOT NULL auto_increment,
  `coins` int(255) NOT NULL default '0',
  `days` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

INSERT INTO `banner_packs` (`id`, `coins`, `days`) VALUES
(1, 750, 1),
(2, 2000, 3),
(4, 4000, 7);