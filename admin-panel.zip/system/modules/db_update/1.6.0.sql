CREATE TABLE IF NOT EXISTS `module_session` (
  `user_id` int(255) NOT NULL default '0',
  `page_id` int(255) NOT NULL default '0',
  `ses_key` int(255) NOT NULL default '0',
  `module` varchar(255) collate utf8_unicode_ci NOT NULL,
  `timestamp` int(255) NOT NULL default '0',
  KEY `user_id` (`user_id`,`page_id`,`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;