<?php
// Update to 1.8.7
if(!mysql_query("SELECT auto_country FROM settings")){$db->Query("ALTER TABLE `settings` ADD `auto_country` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT blog_comments FROM settings")){$db->Query("ALTER TABLE `settings` ADD `blog_comments` INT( 11 ) NOT NULL DEFAULT '1'");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'blog'"))){$db->Query("CREATE TABLE IF NOT EXISTS `blog` (`id` int(255) NOT NULL AUTO_INCREMENT, `author` int(255) NOT NULL DEFAULT '0', `title` varchar(255) NOT NULL, `content` text NOT NULL, `timestamp` int(255) NOT NULL DEFAULT '0', PRIMARY KEY (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'blog_comments'"))){$db->Query("CREATE TABLE IF NOT EXISTS `blog_comments` (`id` int(255) NOT NULL AUTO_INCREMENT, `bid` int(255) NOT NULL DEFAULT '0', `author` int(255) NOT NULL DEFAULT '0', `comment` text NOT NULL, `timestamp` int(255) NOT NULL DEFAULT '0', PRIMARY KEY (`id`), KEY `bid` (`bid`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;;");}

// Update to 1.8.5
if(mysql_query("SELECT cf_bonus FROM users")){$db->Query("ALTER TABLE `users` DROP `cf_bonus`");}

// Update to 1.8.4
if(!mysql_query("SELECT revshare_api FROM settings")){$db->Query("ALTER TABLE `settings` ADD `revshare_api` VARCHAR( 32 ) NOT NULL");}
if(!mysql_query("SELECT fb_app_id FROM settings")){$db->Query("ALTER TABLE `settings` ADD `fb_app_id` VARCHAR( 128 ) NOT NULL");}
if(!mysql_query("SELECT fb_app_secret FROM settings")){$db->Query("ALTER TABLE `settings` ADD `fb_app_secret` VARCHAR( 128 ) NOT NULL");}
if(!mysql_query("SELECT warn_expire FROM users")){$db->Query("ALTER TABLE `users` ADD `warn_expire` INT( 255 ) NOT NULL DEFAULT '0'");}

// Update to 1.8.2
if(!mysql_query("SELECT reg_cash FROM settings")){$db->Query("ALTER TABLE `settings` ADD `reg_cash` DECIMAL( 5, 2 ) NOT NULL DEFAULT '0.00' AFTER `reg_coins`");}
if(!mysql_query("SELECT type FROM coupons")){$db->Query("ALTER TABLE `coupons` ADD `type` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT surf_time_type FROM settings")){$db->Query("ALTER TABLE `settings` ADD `surf_time_type` INT( 11 ) NOT NULL DEFAULT '0' AFTER `surf_time`");}
if(mysql_query("SELECT fb_fan_id FROM settings")){$db->Query("ALTER TABLE `settings` DROP `fb_fan_id`");}

// Update to 1.8.1
if(!mysql_query("SELECT allow_withdraw FROM settings")){$db->Query("ALTER TABLE `settings` ADD `allow_withdraw` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'coins_to_cash'"))){$db->Query("CREATE TABLE IF NOT EXISTS `coins_to_cash` ( `id` int(255) NOT NULL AUTO_INCREMENT, `user` int(11) NOT NULL, `coins` int(255) NOT NULL DEFAULT '0', `cash` decimal(5,2) NOT NULL DEFAULT '0.00', `conv_rate` int(64) NOT NULL DEFAULT '0', `date` int(255) NOT NULL DEFAULT '0', PRIMARY KEY (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");}
if(!mysql_query("SELECT account_balance FROM users")){$db->Query("ALTER TABLE `users` ADD `account_balance` DECIMAL( 5,2 ) NOT NULL DEFAULT '0.00' AFTER `coins`");}
if(mysql_query("SELECT cash FROM users")){$db->Query("UPDATE `users` SET `account_balance`=`account_balance`+`cash`");}
if(mysql_query("SELECT cash FROM users")){$db->Query("ALTER TABLE `users` DROP `cash`");}
if(mysql_query("SELECT pack FROM transactions")){$db->Query("ALTER TABLE `transactions` DROP `pack`");}
if(mysql_query("SELECT points FROM transactions")){$db->Query("ALTER TABLE `transactions` DROP `points`");}

// Update to 1.8.0
if(!mysql_query("SELECT mysql_random FROM settings")){$db->Query("ALTER TABLE `settings` ADD `mysql_random` INT( 11 ) NOT NULL DEFAULT '1'");}
if(!mysql_query("SELECT convert_enabled FROM settings")){$db->Query("ALTER TABLE `settings` ADD `convert_enabled` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT convert_rate FROM settings")){$db->Query("ALTER TABLE `settings` ADD `convert_rate` INT( 255 ) NOT NULL DEFAULT '1000'");}
if(!mysql_query("SELECT min_convert FROM settings")){$db->Query("ALTER TABLE `settings` ADD `min_convert` INT( 64 ) NOT NULL DEFAULT '100'");}
if(!mysql_query("SELECT reason FROM requests")){$db->Query("ALTER TABLE `requests` ADD `reason` VARCHAR( 255 ) NOT NULL");}
if(!mysql_query("SELECT warn_message FROM users")){$db->Query("ALTER TABLE `users` ADD `warn_message` VARCHAR( 255 ) NOT NULL ");}
if(!mysql_query("SELECT user_id FROM transactions")){$db->Query("ALTER TABLE `transactions` ADD `user_id` INT( 255 ) NOT NULL DEFAULT '0' AFTER `user`");}
if(!mysql_query("SELECT payer_email FROM transactions")){$db->Query("ALTER TABLE `transactions` ADD `payer_email` VARCHAR( 128 ) NULL");}
if(!mysql_query("SELECT user_ip FROM transactions")){$db->Query("ALTER TABLE `transactions` ADD `user_ip` VARCHAR( 64 ) NULL");}
if(!mysql_query("SELECT trans_id FROM transactions")){$db->Query("ALTER TABLE `transactions` ADD `trans_id` VARCHAR( 128 ) NOT NULL");}
if(!mysql_query("SELECT ref_source FROM users")){$db->Query("ALTER TABLE `users` ADD `ref_source` VARCHAR( 255 ) NOT NULL DEFAULT '0'");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'user_transactions'"))){$db->Query("CREATE TABLE IF NOT EXISTS `user_transactions` (`id` int(255) NOT NULL AUTO_INCREMENT, `user_id` int(255) NOT NULL DEFAULT '0', `type` int(11) NOT NULL DEFAULT '0', `value` int(255) NOT NULL DEFAULT '0', `cash` decimal(5,2) NOT NULL DEFAULT '0.00', `date` int(255) NOT NULL DEFAULT '0', PRIMARY KEY (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");}

// Update to 1.7.2
if(!mysql_query("SELECT aff_click_req FROM settings")){$db->Query("ALTER TABLE `settings` ADD `aff_click_req` INT( 64 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT paypal_auto FROM settings")){$db->Query("ALTER TABLE `settings` ADD `paypal_auto` INT( 11 ) NOT NULL DEFAULT '1'");}
if(!mysql_query("SELECT payza_auto FROM settings")){$db->Query("ALTER TABLE `settings` ADD `payza_auto` INT( 11 ) NOT NULL DEFAULT '1'");}
if(!mysql_query("SELECT ref_paid FROM users")){$db->Query("ALTER TABLE `users` ADD `ref_paid` INT( 11 ) NOT NULL DEFAULT '1' AFTER `ref`");}
if(!mysql_query("SELECT paid FROM transactions")){$db->Query("ALTER TABLE `transactions` ADD `paid` INT( 11 ) NOT NULL DEFAULT '1'");}
if(!mysql_query("SELECT report_limit FROM settings")){$db->Query("ALTER TABLE `settings` ADD `report_limit` INT( 64 ) NOT NULL DEFAULT '0'");}

// Update to 1.7.1
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'web_stats'"))){$db->Query("CREATE TABLE IF NOT EXISTS `web_stats` (`id` int(255) NOT NULL AUTO_INCREMENT, `module_id` varchar(64) NOT NULL, `module_name` varchar(64) NOT NULL, `value` int(255) NOT NULL DEFAULT '0', PRIMARY KEY (`id`), KEY `module_id` (`module_id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1");}
if(!mysql_query("SELECT aff_reg_days FROM settings")){$db->Query("ALTER TABLE `settings` ADD `aff_reg_days` INT( 64 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT analytics_id FROM settings")){$db->Query("ALTER TABLE `settings` ADD `analytics_id` VARCHAR( 32 ) NOT NULL");}

// Update to v1.7.0
if(mysql_query("SELECT y_name FROM ysub")){$db->Query("ALTER TABLE `ysub` CHANGE `y_name` `title` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL");}
if(mysql_query("SELECT y_link FROM ysub")){$db->Query("ALTER TABLE `ysub` CHANGE `y_link` `url` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL");}
if(!mysql_query("SELECT target_system FROM settings")){$db->Query("ALTER TABLE `settings` ADD `target_system` INT( 11 ) NOT NULL DEFAULT '0'");}

// Update to v1.6.9
if(!mysql_query("SELECT captcha_sys FROM settings")){$db->Query("ALTER TABLE `settings` ADD `captcha_sys` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT recaptcha_pub FROM settings")){$db->Query("ALTER TABLE `settings` ADD `recaptcha_pub` VARCHAR( 255 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT recaptcha_sec FROM settings")){$db->Query("ALTER TABLE `settings` ADD `recaptcha_sec` VARCHAR( 255 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT coins_price FROM p_pack")){$db->Query("ALTER TABLE `p_pack` ADD `coins_price` INT( 255 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT type FROM p_pack")){$db->Query("ALTER TABLE `p_pack` ADD `type` INT( 11 ) NOT NULL DEFAULT '0'");}

// Update to v1.6.8
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'reports'"))){$db->Query("CREATE TABLE IF NOT EXISTS `reports` ( `id` int(255) NOT NULL AUTO_INCREMENT, `page_id` int(255) NOT NULL DEFAULT '0', `page_url` varchar(255) NOT NULL DEFAULT '0', `owner_id` int(255) NOT NULL DEFAULT '0', `reported_by` int(255) NOT NULL DEFAULT '0', `reason` varchar(128) NOT NULL, `count` int(64) NOT NULL DEFAULT '1', `module` varchar(64) NOT NULL, `status` int(11) NOT NULL DEFAULT '0', `timestamp` int(255) NOT NULL DEFAULT '0', PRIMARY KEY (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'user_clicks'"))){$db->Query("CREATE TABLE IF NOT EXISTS `user_clicks` ( `uid` int(11) NOT NULL DEFAULT '0', `module` varchar(64) NOT NULL, `total_clicks` int(255) NOT NULL DEFAULT '0', `today_clicks` int(255) NOT NULL DEFAULT '0', KEY `module` (`module`), KEY `uid` (`uid`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;");}

// Update to v1.6.5
if(!mysql_query("SELECT gateway FROM requests")){$db->Query("ALTER TABLE `requests` ADD `gateway` VARCHAR( 64 ) NOT NULL DEFAULT 'paypal'");}
if(!mysql_query("SELECT log_ip FROM users")){$db->Query("ALTER TABLE `users` ADD `log_ip` VARCHAR( 32 ) NOT NULL DEFAULT '0' AFTER `IP`");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'ban_reasons'"))){$db->Query("CREATE TABLE IF NOT EXISTS `ban_reasons` (`id` int(255) NOT NULL auto_increment, `user` int(255) NOT NULL default '0', `reason` text NOT NULL, `date` int(255) NOT NULL default '0', PRIMARY KEY (`id`), KEY `user` (`user`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1");}

// Update to v1.6.4
if(!mysql_query("SELECT payza FROM settings")){$db->Query("ALTER TABLE `settings` ADD `payza` VARCHAR( 64 ) NOT NULL");}
if(!mysql_query("SELECT payza_security FROM settings")){$db->Query("ALTER TABLE `settings` ADD `payza_security` VARCHAR( 255 ) NOT NULL");}
if(!mysql_query("SELECT paypal_status FROM settings")){$db->Query("ALTER TABLE `settings` ADD `paypal_status` INT( 11 ) NOT NULL DEFAULT '1'");}
if(!mysql_query("SELECT payza_status FROM settings")){$db->Query("ALTER TABLE `settings` ADD `payza_status` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT gateway FROM transactions")){$db->Query("ALTER TABLE `transactions` ADD `gateway` VARCHAR( 64 ) NOT NULL DEFAULT 'paypal'");}

// Update to v1.6.2
if(!mysql_query("SELECT c_discount FROM settings")){$db->Query("ALTER TABLE `settings` ADD `c_discount` INT( 64 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT c_show_msg FROM settings")){$db->Query("ALTER TABLE `settings` ADD `c_show_msg` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT c_text_index FROM settings")){$db->Query("ALTER TABLE `settings` ADD `c_text_index` text NOT NULL");}

// Update to v1.6.1
if(!mysql_query("SELECT hideref FROM settings")){$db->Query("ALTER TABLE `settings` ADD `hideref` INT( 11 ) NOT NULL DEFAULT '0'");}

// Update to v1.6.0
if(!mysql_query("SELECT newsletter FROM users")){$db->Query("ALTER TABLE `users` ADD `newsletter` INT( 11 ) NOT NULL DEFAULT '1' AFTER `online`");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE module_session"))){executeSql("system/modules/db_update/1.6.0.sql");}

// Update to v1.5.1
if(!mysql_query("SELECT surf_fb_skip FROM settings")){$db->Query("ALTER TABLE `settings` ADD `surf_fb_skip` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT surf_fc_req FROM settings")){$db->Query("ALTER TABLE `settings` ADD `surf_fc_req` INT( 11 ) NOT NULL DEFAULT '0'");}

// Update to v1.5.0
if(!mysql_query("SELECT crf_bonus FROM settings")){$db->Query("ALTER TABLE `settings` ADD `crf_bonus` INT( 64 ) NOT NULL DEFAULT '0' AFTER `daily_bonus_vip`");}

// Update to v1.4.0
if(!mysql_query("SELECT c_c_limit FROM settings")){$db->Query("ALTER TABLE `settings` ADD `c_c_limit` INT( 11 ) NOT NULL DEFAULT '2', ADD `c_v_limit` INT( 11 ) NOT NULL DEFAULT '5'");}
if(!mysql_query("SELECT country FROM facebook")){$db->Query("ALTER TABLE `facebook` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM google")){$db->Query("ALTER TABLE `google` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM linkedin")){$db->Query("ALTER TABLE `linkedin` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM retweet")){$db->Query("ALTER TABLE `retweet` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM stumble")){$db->Query("ALTER TABLE `stumble` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM surf")){$db->Query("ALTER TABLE `surf` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM twitter")){$db->Query("ALTER TABLE `twitter` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM ylike")){$db->Query("ALTER TABLE `ylike` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM youtube")){$db->Query("ALTER TABLE `youtube` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM ysub")){$db->Query("ALTER TABLE `ysub` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT country FROM users")){$db->Query("ALTER TABLE `users` ADD `country` VARCHAR( 64 ) NOT NULL DEFAULT '0', ADD `c_changes` INT( 11 ) NOT NULL DEFAULT '0', ADD `sex` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE list_countries"))){executeSql("system/modules/db_update/countries.sql");}

// Update to v1.3.6
if(!mysql_query("SELECT more_per_ip FROM settings")){$db->Query("ALTER TABLE `settings` ADD `more_per_ip` INT( 11 ) NOT NULL DEFAULT '0'");}

// Update to v1.3.4
if(!mysql_query("SELECT def_lang FROM settings")){$db->Query("ALTER TABLE `settings` ADD `def_lang` VARCHAR( 11 ) NOT NULL DEFAULT 'en'");}

// Update to v1.3.3
if(!mysql_query("SELECT daily_bonus_vip FROM settings")){$db->Query("ALTER TABLE `settings` ADD `daily_bonus_vip` INT( 255 ) NOT NULL DEFAULT '0'");}

// Update from other versions
if(!mysql_query("SELECT type FROM facebook")){$db->Query("ALTER TABLE `facebook` ADD `type` INT( 11 ) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT transfer_status FROM settings")){$db->Query("ALTER TABLE settings ADD `transfer_status` INT(11) NOT NULL DEFAULT '0'");}
if(!mysql_query("SELECT transfer_fee FROM settings")){$db->Query("ALTER TABLE settings ADD `transfer_fee` INT(64) NOT NULL DEFAULT '10'");}
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'c_transfers'"))){$db->Query("CREATE TABLE IF NOT EXISTS `c_transfers` (`id` int(255) NOT NULL auto_increment, `receiver` int(255) NOT NULL default '0', `sender` varchar(255) collate utf8_unicode_ci NOT NULL, `coins` int(255) NOT NULL default '0', `date` int(255) NOT NULL default '0', PRIMARY KEY  (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1");}
if(!mysql_query("SELECT reason FROM reports")){$db->Query("ALTER TABLE `reports` ADD `reason` VARCHAR( 255 ) NOT NULL AFTER `reported_by`");}
if(!mysql_query("SELECT owner_id FROM reports")){$db->Query("ALTER TABLE `reports` ADD `owner_id` INT( 255 ) NOT NULL DEFAULT '0' AFTER `page_url`");}
if(!mysql_query("SELECT count FROM reports")){$db->Query("ALTER TABLE `reports` ADD `count` INT( 64 ) NOT NULL DEFAULT '1' AFTER `reported_by`");}
$db->Query("ALTER TABLE `users` CHANGE `country` `country` VARCHAR( 64 ) CHARACTER SET latin2 COLLATE latin2_general_ci NOT NULL DEFAULT '0'");
?>