<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label><?=$lang['fbp_url']?></label> <small style="float:right"><?=$lang['fbp_url_desc']?></small><br/>
	<input class="text-max" type="text" value="http://" name="url" />
</p>
<p>

<textarea maxlength="400" value="" name="title"  style="width:400px;height:260px;">Please Post ONE comment similar to:

- </textarea>
</p>