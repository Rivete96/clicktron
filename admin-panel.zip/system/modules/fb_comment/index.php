<?php
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'fb_comment'"))){executeSql("system/modules/fb_comment/db.sql");}

register_filter('site_menu','fbp1_site_menu');
function fbp1_site_menu($menu) {
    $selected = "";
    if(isset($_GET["p"]) && $_GET["p"] == "fb_comment")
    {
        $selected = 'selected';
    }
    else
    {
        $selected = 'value="fb_comment"';
    }
	return $menu . '<option '.$selected.'>Facebook Photo Comment</a>';
}

register_filter('fb_comment_info','fbp1_info');
function fbp1_info($type) {
    if($type == "db")
    {
        return "fb_comment";
    }
    else if($type == "type")
    {
        return "Facebook Photo Comment";
    }
	else if($type == "name")
    {
        return "Facebook Photo Comment";
    }
}

register_filter('fb_comment_dtf','fb_comment_dtf');
function fb_comment_dtf($type) {
    return "fb_comment";
}

register_filter('add_site_select','fbp1_add_select');
function fbp1_add_select($menu) {
    return $menu . "<option value='fb_comment'>Facebook Photo Comment</option>";
}

register_filter('stats','fbp1_stats');
function fbp1_stats($stats) {
	global $db;
	$sql = $db->Query("SELECT module_name,value FROM `web_stats` WHERE `module_id`='fb_comment'");
	if($db->GetNumRows($sql) == 0){
		$result = $db->FetchArray($sql);
		$sql = $db->Query("SELECT SUM(`clicks`) AS `clicks` FROM `fb_comment`");
		$clicks = $db->FetchArray($sql);
		$clicks = ($clicks['clicks'] > 0 ? $clicks['clicks'] : 0);
		$db->Query("INSERT INTO `web_stats` (`module_id`,`module_name`,`value`)VALUES('fb_comment','Facebook Photo Comment','".$clicks."')");
	}else{
		$result = $db->FetchArray($sql);
		$clicks = ($result['value'] > 0 ? $result['value'] : 0);
	}

    $stat = $db->QueryGetNumRows("SELECT id FROM `fb_comment`");
    return $stats . "<tr><td>".$result['module_name']."</td><td>".number_format($stat)."</td><td>".number_format($clicks)."</td></tr>";
}

register_filter('tot_clicks','fbp1_tot_clicks');
function fbp1_tot_clicks($stats) {
	global $db;
    $clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='fb_comment'"));
    if(empty($clicks['value']) && $clicks['value'] != '0'){
		$sql = $db->Query("SELECT SUM(`clicks`) AS `value` FROM `fb_comment`");
		$clicks = $db->FetchArray($sql);
	}
	return $stats += ($clicks['value'] > 0 ? $clicks['value'] : 0);
}

register_filter('tot_sites','fbp1_tot_sites');
function fbp1_tot_sites($stats) {
	global $db;
    $clicks = $db->QueryGetNumRows("SELECT id FROM `fb_comment`");
    return $stats += $clicks;
}

//Admin
register_filter('admin_s_sites','fbp1_admin_sites');
function fbp1_admin_sites($stats) {
	global $db;
	$clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='fb_comment'"));
	$clicks = ($clicks['value'] > 0 ? $clicks['value'] : 0);
	$today_clicks = $db->FetchArray($db->Query("SELECT SUM(today_clicks) AS value FROM `user_clicks` WHERE `module`='fb_comment'"));
	$today_clicks = ($today_clicks['value'] > 0 ? $today_clicks['value'] : 0);
	$active = $db->QueryGetNumRows("SELECT id FROM `fb_comment`");
	$inactive = $db->QueryGetNumRows("SELECT id FROM `fb_comment` WHERE `active`!='0'");
	return $stats . '<div class="full-stats">
							<h2 class="center">Facebook Photo Comment</h2>
							<div class="stat circular" data-valueFormat="0,0" data-list=\'[{"title":"Pages","val":'.$active.',"percent":'.round((($active - $inactive)/$active)*100, 0).'},{"title":"Clicks","val":'.$clicks.',"percent":0},{"title":"Today Clicks","val":'.$today_clicks.',"percent":0}]\'></div>
						</div>';
}

register_filter('admin_s_menu','fbp1_admin_menu');
function fbp1_admin_menu($menu) {
	return $menu . '<li><a href="index.php?x=sites&s=fb_comment">Facebook Photo Comment</a></li>';
}
?>