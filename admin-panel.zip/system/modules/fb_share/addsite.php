<?php
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$url = $db->EscapeString($_POST['url']);
$title = $db->EscapeString($_POST['title']);

if(empty($title) || empty($url)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_25'].'</div></div>';
}elseif(!preg_match('/^(http|https):\/\/[a-z0-9_]+([\-\.]{1}[a-z_0-9]+)*\.[_a-z]{2,5}'.'((:[0-9]{1,5})?\/.*)?$/i', $url)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_27'].'</div></div>';
}elseif(!preg_match("/^[A-Za-z0-9-_.!?]([A-Za-z\s]*[A-Za-z0-9-_.!?()])*$/", $title)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_28'].'</div></div>';
}elseif($_POST['cpc'] < 2 || $_POST['cpc'] > $maxcpc){
	$msg = '<div class="msg"><div class="error">'.lang_rep($lang['b_29'], array('-MIN-' => '2', '-MAX-' => $maxcpc)).'</div></div>';
}elseif($gender < 0 || $gender > 2) {
	$msg = '<div class="msg"><div class="error">'.$lang['b_219'].'</div></div>';
}elseif(!in_array($country, $ctrs) && $country != '0') {
	$msg = '<div class="msg"><div class="error">'.$lang['b_220'].'</div></div>';
}else{
	$sql = $db->Query("SELECT id FROM `fb_share` WHERE `url`='".$url."'");
	if($db->GetNumRows($sql) > 0){
		$msg = '<div class="msg"><div class="error">'.$lang['fb_share_05'].'</div></div>';
	}elseif(preg_match("|^http(s)?://(www.)?facebook.([a-z]+)/(.*)?$|i", $url)){
		$msg = '<div class="msg"><div class="error">'.$lang['fb_share_01'].'</div></div>';
	}else{

		function fb_check($url){
			$url = get_data("https://graph.facebook.com/fql?q=SELECT+share_count+FROM+link_stat+WHERE+url='".$url."'");
			$likes = json_decode($url, true);
			$likes = ''.$likes['data'][0]['share_count'].'';
			if($likes != ''){
				return 1;
			}else{
				return 0;
			}
		}
		
		if(fb_check($url) == 0){
			$msg = '<div class="msg"><div class="error">'.$lang['fb_share_13'].'</div></div>';
		}else{
			$db->Query("INSERT INTO `fb_share` (user, url, title, cpc, country, sex) VALUES('".$data['id']."', '".$url."', '".$title."', '".$cpc."', '".$country."', '".$gender."') ");
			$msg = '<div class="msg"><div class="success">'.$lang['fb_share_02'].'</div></div>';
			$error = 0;
		}
	}
}
?>