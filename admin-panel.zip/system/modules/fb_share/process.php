<?
define('BASEPATH', true);
include('../../config.php');
if(!$is_online){ echo '<div class="msg"><div class="error">'.$lang['fb_share_06'].'</div></div>'; exit; }

if(!empty($site['fb_app_id']) && !empty($site['fb_app_secret'])){
	require_once('../../libs/fb/facebook.php');
	$facebook = new Facebook(array(
		   'appId'  => $site['fb_app_id'],
		   'secret' => $site['fb_app_secret'],
		   'cookie' => true,
	));
	function get_shares($url){
		global $facebook;
		try {
			$response = $facebook->api(array(
				 'method'	=> 'fql.query',
				 'query' 	=> "SELECT share_count FROM link_stat WHERE url='".urlencode($url)."'",
				 'callback' => ''
			));
			$shares = $response[0]['share_count'];
		} catch (FacebookApiException $e) {
			$url = get_data("https://graph.facebook.com/fql?q=SELECT+share_count+FROM+link_stat+WHERE+url='".urlencode($url)."'");
			$shares = json_decode($url, true);
			$shares = $shares['data'][0]['share_count'];
		}
		return (empty($shares) ? '0' : $shares);
	}
}else{
	function get_shares($url){
		$url = get_data("https://graph.facebook.com/fql?q=SELECT+share_count+FROM+link_stat+WHERE+url='".urlencode($url)."'");
		$shares = json_decode($url, true);
		$shares = $shares['data'][0]['share_count'];
		return (empty($shares) ? '0' : $shares);
	}
}

if(isset($_POST['get']) && $_POST['url'] != '' && $_POST['pid'] > 0){
	$pid = $db->EscapeString($_POST['pid']);
	$sit = $db->FetchArray($db->Query("SELECT url FROM `fb_share` WHERE `id`='".$pid."'"));
	$key = get_shares($sit['url']);

	if($db->QueryGetNumRows("SELECT ses_key FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$pid."' AND `module`='fb_share'") == 0){
		$result	= $db->Query("INSERT INTO `module_session` (`user_id`,`page_id`,`ses_key`,`module`,`timestamp`)VALUES('".$data['id']."','".$pid."','".$key."','fb_share','".time()."')");
	}else{
		$result	= $db->Query("UPDATE `module_session` SET `ses_key`='".$key."' WHERE `user_id`='".$data['id']."' AND `page_id`='".$pid."' AND `module`='fb_share'");
	}

	if($result){
		echo '1';
	}
}elseif(isset($_POST['step']) && $_POST['step'] == "skip" && is_numeric($_POST['sid']) && !empty($data['id'])){
	$id = $db->EscapeString($_POST['sid']);
	$sql = $db->Query("SELECT site_id FROM `fb_shared` WHERE `user_id`='".$data['id']."' AND `site_id`='".$id."'");

	if($db->GetNumRows($sql) == 0){
		$db->Query("INSERT INTO `fb_shared` (user_id, site_id) VALUES('".$data['id']."', '".$id."')");
		echo '<div class="msg"><div class="info">'.$lang['fb_share_03'].'</div></div>';
	}
}elseif(isset($_POST['id'])){
	$id = $db->EscapeString($_POST['id']);
	$sit = $db->FetchArray($db->Query("SELECT id,user,url,cpc FROM `fb_share` WHERE `id`='".$id."'"));
	$check = $db->QueryGetNumRows("SELECT site_id FROM `fb_shared` WHERE `user_id`='".$data['id']."' AND `site_id`='".$sit['id']."'");

	$mod_ses = $db->FetchArray($db->Query("SELECT ses_key FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='fb_share'"));
	if($mod_ses['ses_key'] != '' && get_shares($sit['url']) > $mod_ses['ses_key']){
		$valid = true;
	}else{
		$valid = false;
	}

	if($valid && !empty($id) && !empty($data['id']) && $check == 0 && $sit['cpc'] >= 2){
		$db->Query("UPDATE `users` SET `coins`=`coins`+'".($sit['cpc']-1)."' WHERE `id`='".$data['id']."'");
		$db->Query("UPDATE `users` SET `coins`=`coins`-'".$sit['cpc']."' WHERE `id`='".$sit['user']."'");
		$db->Query("UPDATE `fb_share` SET `clicks`=`clicks`+'1' WHERE `id`='".$id."'");
		$db->Query("UPDATE `web_stats` SET `value`=`value`+'1' WHERE `module_id`='fb_share'");
		$db->Query("INSERT INTO `fb_shared` (user_id, site_id) VALUES('".$data['id']."','".$sit['id']."')");
		$db->Query("DELETE FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='fb_share'");

		if($db->QueryGetNumRows("SELECT uid FROM `user_clicks` WHERE `uid`='".$data['id']."' AND `module`='fb_share' LIMIT 1") == 0){
			$db->Query("INSERT INTO `user_clicks` (`uid`,`module`,`total_clicks`,`today_clicks`)VALUES('".$data['id']."','fb_share','1','1')");
		}else{
			$db->Query("UPDATE `user_clicks` SET `total_clicks`=`total_clicks`+'1', `today_clicks`=`today_clicks`+'1' WHERE `uid`='".$data['id']."' AND `module`='fb_share'");
		}
		echo '1';
	}else{
		echo '0';
	}
}
$db->Close();
?>