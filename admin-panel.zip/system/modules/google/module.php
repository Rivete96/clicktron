<?if(! defined('BASEPATH') ){ exit('Unable to view file.'); }?>
<?
$dbt_value = '';
if($site['target_system'] != 2){
	$dbt_value = " AND (a.country = '".$data['country']."' OR a.country = '0') AND (a.sex = '".$data['sex']."' OR a.sex = '0')";
}

$sql = $db->Query("SELECT a.id, a.url, a.title, a.cpc, b.premium FROM google a LEFT JOIN users b ON b.id = a.user LEFT JOIN plused c ON c.user_id = '".$data['id']."' AND c.site_id = a.id WHERE a.active = '0' AND (b.coins >= a.cpc AND a.cpc >= '2') AND (c.site_id IS NULL AND a.user !='".$data['id']."')".$dbt_value." ORDER BY a.cpc DESC, b.premium DESC".($site['mysql_random'] == 1 ? ', RAND()' : '')." LIMIT 1");
$sites = $db->FetchArrayAll($sql);
if($sites != FALSE){
?>
<script type="text/javascript">
	var report_msg1 = '<?=mysql_escape_string($lang['b_277'])?>';
	var report_msg2 = '<?=mysql_escape_string($lang['b_236'])?>';
	var report_msg3 = '<?=mysql_escape_string($lang['b_237'])?>';
	var report_msg4 = '<?=mysql_escape_string(lang_rep($lang['b_252'], array('-NUM-' => $site['report_limit'])))?>';
	var start_click = 1;
	var end_click = <?=$db->GetNumRows($sql)?>;
	eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('4 7(a,b,c){8 e=9(f);g(e){$.h({i:"j",5:"k/l.m",n:o,p:"q="+a+"&5="+b+"&r="+c+"&s="+e,t:4(d){u(d){6\'1\':0(v);w(a,\'1\');3;6\'2\':0(x);3;y:0(z);3}}})}}',36,36,'alert|||break|function|url|case|report_page|var|prompt||||||report_msg1|if|ajax|type|POST|system|report|php|cache|false|data|id|module|reason|success|switch|report_msg2|skipElement|report_msg4|default|report_msg3'.split('|'),0,{}))
	eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('2 7(){8(9<A){9=9+1}B{C.D(E)}}2 F(b,c){$("#5").3("<6 l=\\"6/m.n\\" /><G>");$.d({f:"o",g:"h/p/q/r.i",s:"H=I&J="+b,j:2(a){$("#5").3(a);k(b);7()}})}2 K(b){8(b.L=="M"){$("#5").3("<6 l=\\"6/m.n\\" />");t c=b.N;8(c.O(c.u-1)=="/"){c=c.P(0,c.u-1)}4=v.w(c).Q;t e=$("#"+4+"R").3();$.d({f:"o",g:"h/p/q/r.i",s:"4="+4,x:y,j:2(a){$("#5").3(a);k(4);7();z()}})}}2 k(a){v.w(a).S.T="U"}2 z(){$.d({f:"V",g:"h/W.i",x:y,j:2(a){$("#X").3(a)}})}',60,60,'||function|html|id|Hint|img|click_refresh|if|start_click||||ajax||type|url|system|php|success|remove|src|loader|gif|POST|modules|google|process|data|var|length|document|getElementById|cache|false|refresh_coins|end_click|else|location|reload|true|skipElement|br|step|skip|sid|click_callback|state|on|href|charAt|substring|innerHTML|coins|style|display|none|GET|uCoins|c_coins'.split('|'),0,{}))
</script>
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<center><div id="Hint"></div></center>
<div id="tbl">
<?
  foreach($sites as $sit)
  {
?>	
<div class="follow<?=($sit['premium'] > 0 ? '_vip' : '')?>" id="<?=$sit['id']?>">
	<center>
	<center>
<b class="fs18"><font color="black">You will get <?=($sit['cpc']-1)?> points for Plusing.</font></b>
<p></p>

	<div id="<?=rtrim($sit['url'],"/")?>" style="display:none;"><?=$sit['id']?></div>
	<div><g:plusone callback='click_callback' href="<?=$sit['url']?>" size="medium"></g:plusone></div>
<p></p>
			<font style="font-size:1.2em;"><a href="javascript:void(0);" onclick="skipElement('<?=$sit['id']?>','0');" style="color: black;font-size:0.9em;">Skip</a></font>
	<span style="position:absolute;bottom:1px;right:134px;"><a href="javascript:void(0);" onclick="report_page('<?=$sit['id']?>','<?=base64_encode($sit['url'])?>','google');"><img src="img/report.png" alt="Report" title="Report" border="0" /></a></span>
</div>
<?}?>
</div>
<?}else{?>
	<div class="err1"><?=$lang['b_163']?></div>
	<div class="not1"><a target="_blank" style="color:black" href="buy.php"><u><?=$lang['b_164']?></u></a></div>
<?}?>