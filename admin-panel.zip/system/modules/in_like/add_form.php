<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label>Photo URL:</label> <small style="float:right"><?=$lang['likepin_url_desc']?></small><br/>
	<input class="text-max" type="text" value="http://" name="url" />
</p>