<?php
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'in_like'"))){executeSql("system/modules/in_like/db.sql");}

register_filter('site_menu','in_like_site_menu');
function in_like_site_menu($menu) {
    $selected = "";
    if(isset($_GET["p"]) && $_GET["p"] == "in_like")
    {
        $selected = 'selected';
    }
    else
    {
        $selected = 'value="in_like"';
    }
	return $menu . '<option '.$selected.'>Instagram Likes</a>';
}

register_filter('add_site_select','in_like_add_select');
function in_like_add_select($menu) {
    if(isset($_POST["type"]) && $_POST["type"] == "in_like")
    {
	    return $menu . "<option value='in_like' selected>Instagram Likes</option>";
    }
    else
    {
        return $menu . "<option value='in_like'>Instagram Likes</option>";
    }
}

register_filter('in_like_info','in_like_info');
function in_like_info($type) {
    if($type == "db")
    {
        return "in_like";
    }
    else if($type == "type")
    {
        return "Instagram Likes";
    }
	else if($type == "name")
    {
        return "Instagram Likes";
    }
}

register_filter('in_like_dtf','in_like_dtf');
function in_like_dtf($type) {
    return "in_like";
}

register_filter('stats','in_like_stats');
function in_like_stats($stats) {
	global $db;
	$sql = $db->Query("SELECT module_name,value FROM `web_stats` WHERE `module_id`='in_like'");
	if($db->GetNumRows($sql) == 0){
		$result = $db->FetchArray($sql);
		$sql = $db->Query("SELECT SUM(`clicks`) AS `clicks` FROM `in_like`");
		$clicks = $db->FetchArray($sql);
		$clicks = ($clicks['clicks'] > 0 ? $clicks['clicks'] : 0);
		$db->Query("INSERT INTO `web_stats` (`module_id`,`module_name`,`value`)VALUES('in_like','Instagram Likes','".$clicks."')");
	}else{
		$result = $db->FetchArray($sql);
		$clicks = ($result['value'] > 0 ? $result['value'] : 0);
	}

    $stat = $db->QueryGetNumRows("SELECT id FROM `in_like`");
    return $stats . "<tr><td>".$result['module_name']."</td><td>".number_format($stat)."</td><td>".number_format($clicks)."</td></tr>";
}

register_filter('tot_clicks','in_like_tot_clicks');
function in_like_tot_clicks($stats) {
	global $db;
    $clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='in_like'"));
    if(empty($clicks['value']) && $clicks['value'] != '0'){
		$sql = $db->Query("SELECT SUM(`clicks`) AS `value` FROM `in_like`");
		$clicks = $db->FetchArray($sql);
	}
	return $stats += ($clicks['value'] > 0 ? $clicks['value'] : 0);
}

register_filter('tot_sites','in_like_tot_sites');
function in_like_tot_sites($stats) {
	global $db;
    $clicks = $db->QueryGetNumRows("SELECT id FROM `in_like`");
    return $stats += $clicks;
}

//Admin
register_filter('admin_s_sites','in_like_admin_clicks');
function in_like_admin_clicks($stats) {
	global $db;
	$clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='in_like'"));
	$clicks = ($clicks['value'] > 0 ? $clicks['value'] : 0);
	$today_clicks = $db->FetchArray($db->Query("SELECT SUM(today_clicks) AS value FROM `user_clicks` WHERE `module`='in_like'"));
	$today_clicks = ($today_clicks['value'] > 0 ? $today_clicks['value'] : 0);
	$active = $db->QueryGetNumRows("SELECT id FROM `in_like`");
	$inactive = $db->QueryGetNumRows("SELECT id FROM `in_like` WHERE `active`!='0'");
	return $stats . '<div class="full-stats">
							<h2 class="center">Instagram Likes</h2>
							<div class="stat circular" data-valueFormat="0,0" data-list=\'[{"title":"Pages","val":'.$active.',"percent":'.round((($active - $inactive)/$active)*100, 0).'},{"title":"Clicks","val":'.$clicks.',"percent":0},{"title":"Today Clicks","val":'.$today_clicks.',"percent":0}]\'></div>
						</div>';
}

register_filter('admin_s_menu','in_like_admin_menu');
function in_like_admin_menu($menu) {
	return $menu . '<li><a href="index.php?x=sites&s=in_like">PT Likes</a></li>';
}
?>