<?php
register_filter('index_icons_on','lkd_icon_on');
function lkd_icon_on($icons) {
	return $icons . '<a href="p.php?p=linkedin"><img class="exchange_icon" src="img/icons/linkedin.png" alt="Linkedin" /></a>';
}

register_filter('index_icons_off','lkd_icon_off');
function lkd_icon_off($icons) {
	return $icons . '<img class="exchange_icon" src="img/icons/linkedin.png" alt="Linkedin" />';
}

register_filter('top_menu_earn','lkd_top_menu');
function lkd_top_menu($menu) {
	$selected = (isset($_GET["p"]) && $_GET["p"] == "linkedin" ? ' active' : '');
	return $menu . '<div class="ucp_link'.$selected.'"><a href="p.php?p=linkedin">LinkedIn Share</a></div>';
}

register_filter('site_menu','lkd_site_menu');
function lkd_site_menu($menu) {
    $selected = "";
    if(isset($_GET["p"]) && $_GET["p"] == "linkedin")
    {
        $selected = 'selected';
    }
    else
    {
        $selected = 'value="linkedin"';
    }
	return $menu . '<option '.$selected.'>LinkedIn Share</a>';
}

register_filter('linkedin_info','lkd_info');
function lkd_info($type) {
    if($type == "db")
    {
        return "linkedin";
    }
    else if($type == "type")
    {
        return "Linkedin";
    }
	else if($type == "name")
    {
        return "Linkedin Share";
    }
}

register_filter('linkedin_dtf','linkedin_dtf');
function linkedin_dtf($type) {
    return "linkedin";
}

register_filter('add_site_select','lkd_add_select');
function lkd_add_select($menu) {
    return $menu . "<option value='linkedin'>LinkedIn Share</option>";
}

register_filter('stats','lkd_stats');
function lkd_stats($stats) {
	global $db;
	$sql = $db->Query("SELECT module_name,value FROM `web_stats` WHERE `module_id`='linkedin'");
	if($db->GetNumRows($sql) == 0){
		$result = $db->FetchArray($sql);
		$sql = $db->Query("SELECT SUM(`clicks`) AS `clicks` FROM `linkedin`");
		$clicks = $db->FetchArray($sql);
		$clicks = ($clicks['clicks'] > 0 ? $clicks['clicks'] : 0);
		$db->Query("INSERT INTO `web_stats` (`module_id`,`module_name`,`value`)VALUES('linkedin','LinkedIn Shares','".$clicks."')");
	}else{
		$result = $db->FetchArray($sql);
		$clicks = ($result['value'] > 0 ? $result['value'] : 0);
	}

    $stat = $db->QueryGetNumRows("SELECT id FROM `linkedin`");
    return $stats . "<tr><td>".$result['module_name']."</td><td>".number_format($stat)."</td><td>".number_format($clicks)."</td></tr>";
}

register_filter('tot_clicks','lkd_tot_clicks');
function lkd_tot_clicks($stats) {
	global $db;
    $clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='linkedin'"));
    if(empty($clicks['value']) && $clicks['value'] != '0'){
		$sql = $db->Query("SELECT SUM(`clicks`) AS `value` FROM `linkedin`");
		$clicks = $db->FetchArray($sql);
	}
	return $stats += ($clicks['value'] > 0 ? $clicks['value'] : 0);
}

register_filter('tot_sites','lkd_tot_sites');
function lkd_tot_sites($stats) {
	global $db;
    $clicks = $db->QueryGetNumRows("SELECT id FROM `linkedin`");
    return $stats += $clicks;
}

//Admin
register_filter('admin_s_sites','lkd_admin_clicks');
function lkd_admin_clicks($stats) {
	global $db;
	$clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='linkedin'"));
	$clicks = ($clicks['value'] > 0 ? $clicks['value'] : 0);
	$today_clicks = $db->FetchArray($db->Query("SELECT SUM(today_clicks) AS value FROM `user_clicks` WHERE `module`='linkedin'"));
	$today_clicks = ($today_clicks['value'] > 0 ? $today_clicks['value'] : 0);
	$active = $db->QueryGetNumRows("SELECT id FROM `linkedin`");
	$inactive = $db->QueryGetNumRows("SELECT id FROM `linkedin` WHERE `active`!='0'");
	return $stats . '<div class="full-stats">
							<h2 class="center">LinkedIn Share</h2>
							<div class="stat circular" data-valueFormat="0,0" data-list=\'[{"title":"Pages","val":'.$active.',"percent":'.round((($active - $inactive)/$active)*100, 0).'},{"title":"Clicks","val":'.$clicks.',"percent":0},{"title":"Today Clicks","val":'.$today_clicks.',"percent":0}]\'></div>
						</div>';
}

register_filter('admin_s_menu','lkd_admin_menu');
function lkd_admin_menu($menu) {
	return $menu . '<li><a href="index.php?x=sites&s=linkedin">LinkedIn Share</a></li>';
}
?>