<?php
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$url = $db->EscapeString($_POST['url']);

if(empty($url)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_25'].'</div></div>';
}elseif(!preg_match('/^(http|https):\/\/[a-z0-9_]+([\-\.]{1}[a-z_0-9]+)*\.[_a-z]{2,5}'.'((:[0-9]{1,5})?\/.*)?$/i', $url)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_27'].'</div></div>';
}elseif($_POST['cpc'] < 2 || $_POST['cpc'] > $maxcpc){
	$msg = '<div class="msg"><div class="error">'.lang_rep($lang['b_29'], array('-MIN-' => '2', '-MAX-' => $maxcpc)).'</div></div>';
}elseif($gender < 0 || $gender > 2) {
	$msg = '<div class="msg"><div class="error">'.$lang['b_219'].'</div></div>';
}elseif(!in_array($country, $ctrs) && $country != '0') {
	$msg = '<div class="msg"><div class="error">'.$lang['b_220'].'</div></div>';
}else{
	if(!preg_match("|^http(s)?://youtube.com/(.*)?$|i", $url)){
		$msg = '<div class="msg"><div class="error">'.$lang['ins_01'].'</div></div>';
	}else{
		$pins = @get_data($url);
		$match = array(); 
		$puser['url'] = $extract[3];

		if($db->QueryGetNumRows("SELECT id FROM `yts` WHERE `url`='".$puser['url']."'") > 0){
			$msg = '<div class="msg"><div class="error">'.$lang['ins_02'].'</div></div>';
		}elseif($puser['url'] == '' || $puser['title'] == ''){
			$msg = '<div class="msg"><div class="error">'.$lang['ins_03'].'</div></div>';
		}else{
			$db->Query("INSERT INTO `yts` (user, url, title, p_av, cpc) VALUES('".$data['id']."', '".$puser['url']."', '".$puser['title']."', '".$puser['av']."', '".$cpc."') ");
			$msg = '<div class="msg"><div class="success">'.$lang['ins_04'].'</div></div>';
			$error = 0;
		}
	}
}
?>