<?if(! defined('BASEPATH') ){ exit('Unable to view file.'); }?>
<?
$dbt_value = '';
if($site['target_system'] != 2){
	$dbt_value = " AND (a.country = '".$data['country']."' OR a.country = '0') AND (a.sex = '".$data['sex']."' OR a.sex = '0')";
}

$sql = $db->Query("SELECT a.id, a.url, a.title, a.cpc, b.premium FROM stumble a LEFT JOIN users b ON b.id = a.user LEFT JOIN stumbled c ON c.user_id = '".$data['id']."' AND c.site_id = a.id WHERE a.active = '0' AND (b.coins >= a.cpc AND a.cpc >= '2') AND (c.site_id IS NULL AND a.user !='".$data['id']."')".$dbt_value." ORDER BY a.cpc DESC, b.premium DESC".($site['mysql_random'] == 1 ? ', RAND()' : '')." LIMIT 25");
$sites = $db->FetchArrayAll($sql);
if($sites != FALSE){
?>


<script type="text/javascript">
	msg1 = '<?=mysql_escape_string($lang['su_08'])?>';
	msg2 = '<?=mysql_escape_string($lang['su_09'])?>';
	msg3 = '<?=mysql_escape_string($lang['su_10'])?>';
	msg4 = '<?=mysql_escape_string($lang['su_11'])?>';
	msg5 = '<?=mysql_escape_string($lang['su_12'])?>';
	var report_msg1 = '<?=mysql_escape_string($lang['b_277'])?>';
	var report_msg2 = '<?=mysql_escape_string($lang['b_236'])?>';
	var report_msg3 = '<?=mysql_escape_string($lang['b_237'])?>';
	var report_msg4 = '<?=mysql_escape_string(lang_rep($lang['b_252'], array('-NUM-' => $site['report_limit'])))?>';
	hideref = <?=($site['hideref'] != '' ? $site['hideref'] : 0)?>;
	rs_key = '<?=($site['revshare_api'] != '' ? $site['revshare_api'] : 0)?>';
	var start_click = 1;
	var end_click = <?=$db->GetNumRows($sql)?>;
	eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('4 7(a,b,c){8 e=9(f);g(e){$.h({i:"j",5:"k/l.m",n:o,p:"q="+a+"&5="+b+"&r="+c+"&s="+e,t:4(d){u(d){6\'1\':0(v);w(a,\'1\');3;6\'2\':0(x);3;y:0(z);3}}})}}',36,36,'alert|||break|function|url|case|report_page|var|prompt||||||report_msg1|if|ajax|type|POST|system|report|php|cache|false|data|id|module|reason|success|switch|report_msg2|skipuser|report_msg4|default|report_msg3'.split('|'),0,{}))
	eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('4 A(){8(B<10){B=B+1}p{M.11(12)}}4 13(b,c){$("#6").5("<m C=\\"m/D.E\\" /><F>");$.t({u:"G",q:"v/H/I/J.x",K:"14=15&16="+b,s:4(a){$("#6").5(a);L(b);A()}})}n o;4 17(c,d,e,w,h,f,g){8(o&&!o.N){}p{n i=O.P/2-w/2;n j=O.Q/2-h/2;n k=d;$("#6").5("<m C=\\"m/D.E\\" /><F>");$.t({u:"G",q:"v/H/I/J.x",K:"18=1&q="+d+"&19="+c,s:4(a){8(!1a(a)){$("#6").5("<3 7=\\"y\\"><3 7=\\"1b\\">"+1c+"</3></3>");n d=1d(4(){o.1e()},1f);n b=1g(4(){8(o.N){R(b);R(d);S(c,f,g)}},1h)}p{$("#6").5("<3 7=\\"y\\"><3 7=\\"T\\">"+1i+"</3></3>")}}});8(z==1){k=\'U://z.V/?\'+d}p 8(z==2&&W!=\'0\'){l=\'U://1j.z.V/r/\'+W+\'/\'+d}o=1k.1l(k,e,"1m=9, M=9, 1n=9, 1o=9, 1p=9, 1q=1r, 1s=9, 1t=9, P="+w+", Q="+h+", 1u="+j+", 1v="+i)}}4 S(b,c,e){$("#6").5("<m C=\\"m/D.E\\" /><F>");$.t({u:"G",q:"v/H/I/J.x",X:Y,K:"1w="+b,s:4(a){8(a==1){$("#6").5("<3 7=\\"y\\"><3 7=\\"s\\">"+1x+" <b>"+c+"</b>"+1y+"</3></3>");L(b);A();Z()}p{$("#6").5("<3 7=\\"y\\"><3 7=\\"T\\">"+1z+"</3></3>")}}})}4 L(a){1A.1B(a).1C.1D="1E"}4 Z(){$.t({u:"1F",q:"v/1G.x",X:Y,s:4(a){$("#1H").5(a)}})}',62,106,'|||div|function|html|Hint|class|if|no|||||||||||||img|var|targetWin|else|url||success|ajax|type|system||php|msg|hideref|click_refresh|start_click|src|loader|gif|br|POST|modules|su|process|data|remove|location|closed|screen|width|height|clearTimeout|do_click|error|http://anonymgoto.com/?u=http|org|rs_key|cache|false|refresh_coins|end_click|reload|true|skipuser|step|skip|sid|ModulePopup|get|pid|isNaN|info|msg1|setTimeout|close|20000|setInterval|1000|msg2|rs|window|open|toolbar|directories|status|menubar|scrollbars|yes|resizable|copyhistory|top|left|id|msg4|msg5|msg3|document|getElementById|style|display|none|GET|uCoins|c_coins'.split('|'),0,{}))
</script>
<div id="Hint"></div>
<div id="getpoints">
<?
  foreach($sites as $sit){
?>	
<div class="follow<?=($sit['premium'] > 0 ? '_vip' : '')?>" id="<?=$sit['id']?>">
	<center>
<b class="fs18"><font color="black">You will get <?=($sit['cpc']-1)?> points for Liking.</font></b>
		<span style="display:block;height:100px"><img src="img/icons/su.png" height="100" alt="<?=truncate($sit['title'], 25)?>" title="<?=truncate($sit['title'], 25)?>" /></span>
            <center><a href="javascript:void(0);" class="single_like_button btn3-wrap" onclick="ModulePopup('<?=$sit['id']?>','<?=$sit['url']?>','Stumbleupon','900','500','<?=($sit['cpc']-1)?>','1');">
						                    <span></span><div class="btn3">Follow</div></a></center>
		<font style="font-size:1.2em;"><a href="javascript:void(0);" onclick="skipuser('<?=$sit['id']?>','<?=$sit['url']?>');remove('<?=$sit['id']?>');" style="color: black;font-size:0.9em;">Skip</a></font>
		<span style="position:absolute;bottom:60px;right:134px;"><a href="javascript:void(0);" onclick="report_page('<?=$sit['id']?>','<?=base64_encode($sit['url'])?>','stumble');"><img src="img/report.png" alt="Report" title="Report" border="0" /></a></span>
	</center>
<style>
#hides { color: transparent; }
</style>
<pre id="hides">-
-
</pre>
</div>
<?}?>
</div>
<?}else{?>
<div class="err1"><?=$lang['b_163']?></div>
<div class="not1"><a style="color:black" href="buy.php"><u><?=$lang['b_164']?></u></a></div>
<?}?>