<?
define('BASEPATH', true);
require_once('../../config.php');
if(!$is_online){exit;}

function get_followers($v){
	$x = explode('/', $v);
	if($x[5] != 'likes'){
		$v = $v.'/likes';
	}
	$v = get_data($v);
	preg_match('/"countFollowers":"(.*?)"/i', $v, $content);
	preg_match('/([\d]+)/', $content[1], $match);
	return $match[0];
}

if(isset($_POST['get']) && $_POST['pid'] > 0){
	$pid = $db->EscapeString($_POST['pid']);
	$sit = $db->QueryFetchArray("SELECT url FROM `stumble` WHERE `id`='".$pid."'");
	$key = get_followers($sit['url']);

	if($db->QueryGetNumRows("SELECT ses_key FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$pid."' AND `module`='su'") == 0){
		$result	= $db->Query("INSERT INTO `module_session` (`user_id`,`page_id`,`ses_key`,`module`,`timestamp`)VALUES('".$data['id']."','".$pid."','".$key."','su','".time()."')");
	}else{
		$result	= $db->Query("UPDATE `module_session` SET `ses_key`='".$key."' WHERE `user_id`='".$data['id']."' AND `page_id`='".$pid."' AND `module`='su'");
	}
	if($result){
		echo '1';
	}
}elseif(isset($_POST['step']) && $_POST['step'] == "skip" && is_numeric($_POST['sid']) && !empty($data['id'])){
	$id = $db->EscapeString($_POST['sid']);
	$sql = $db->Query("SELECT site_id FROM `stumbled` WHERE `user_id`='".$data['id']."' AND `site_id`='".$id."'");
		
	if($db->GetNumRows($sql) == 0){
		$db->Query("INSERT INTO `stumbled` (user_id, site_id) VALUES('".$data['id']."', '".$id."')");
		echo '<div class="msg"><div class="info">'.$lang['su_07'].'</div></div>';
	}
}

if(isset($_POST['id'])){
	$uid = $db->EscapeString($_POST['id']);
	$sit = $db->FetchArray($db->Query("SELECT id,user,url,cpc FROM `stumble` WHERE `id`='".$uid."'"));
	$mod_ses = $db->FetchArray($db->Query("SELECT ses_key FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='su'"));

	if($mod_ses['ses_key'] != '' && get_followers($sit['url']) > $mod_ses['ses_key']){	
		$plused = $db->QueryGetNumRows("SELECT site_id FROM `stumbled` WHERE `site_id`='".$uid."' AND `user_id`='".$data['id']."'");

		if($plused < 1 && $sit['cpc'] >= 2) {
			$db->Query("UPDATE `users` SET `coins`=`coins`+'".($sit['cpc']-1)."' WHERE `id`='".$data['id']."'");
			$db->Query("UPDATE `users` SET `coins`=`coins`-'".$sit['cpc']."' WHERE `id`='".$sit['user']."'");
			$db->Query("UPDATE `stumble` SET `clicks`=`clicks`+'1' WHERE `id`='".$uid."'");
			$db->Query("UPDATE `web_stats` SET `value`=`value`+'1' WHERE `module_id`='stumble'");
			$db->Query("INSERT INTO `stumbled` (user_id, site_id) VALUES('".$data['id']."', '".$uid."')");
			$db->Query("DELETE FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='su'");

			if($db->QueryGetNumRows("SELECT uid FROM `user_clicks` WHERE `uid`='".$data['id']."' AND `module`='su' LIMIT 1") == 0){
				$db->Query("INSERT INTO `user_clicks` (`uid`,`module`,`total_clicks`,`today_clicks`)VALUES('".$data['id']."','su','1','1')");
			}else{
				$db->Query("UPDATE `user_clicks` SET `total_clicks`=`total_clicks`+'1', `today_clicks`=`today_clicks`+'1' WHERE `uid`='".$data['id']."' AND `module`='su'");
			}
			echo '1';
		}else{
			echo '2';
		}
	}else{
		echo '0';
	}
}
?>