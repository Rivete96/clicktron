<?
define('BASEPATH', true);
include('../../config.php');
include_once('../../../languages/'.$CONF['language'].'/modules/surf.php');

if(isset($_POST['data'])){
	$x = $db->EscapeString($_POST['data']);
	$site = $db->FetchArray($db->Query("SELECT id, confirm FROM `surf` WHERE `id`='".$x."'"));
	
	if($site['id'] != "" && $x != "" && $site['confirm'] != 0){
		mysql_query("UPDATE `surf` SET `confirm`='0' WHERE `id`='".$site['id']."'");
		echo '<font size=2><b>'.$lang['surf_02'].'</b></font>';
	}else{
		echo '<font size=2><b>'.$lang['surf_03'].'</b></font>';
	}
}
?>