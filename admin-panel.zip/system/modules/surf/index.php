<?php
if(!mysql_query("SELECT surf_time FROM settings")){
    mysql_query("ALTER TABLE settings ADD surf_time int(50) NOT NULL DEFAULT '10'");
}elseif(!mysql_query("SELECT surf_type FROM settings")){
    mysql_query("ALTER TABLE settings ADD surf_type int(11) NOT NULL DEFAULT '0'");
}

register_filter('index_icons_on','surf_icon_on');
function surf_icon_on($icons) {
	return $icons . '<a href="surf.php" target="_blank"><img class="exchange_icon" src="img/icons/feed.png" alt="Hits" /></a>';
}

register_filter('index_icons_off','surf_icon_off');
function surf_icon_off($icons) {
	return $icons . '<img class="exchange_icon" src="img/icons/feed.png" alt="Hits" />';
}

register_filter('top_menu_earn','surf_top_menu');
function surf_top_menu($menu) {
	$selected = (isset($_GET["p"]) && $_GET["p"] == "surf" ? ' active' : '');
	$stype = mysql_fetch_array(mysql_query("SELECT surf_type FROM `settings` LIMIT 1"));
	if($stype['surf_type'] == 0){
		return $menu . '<div class="ucp_link"><a target="_blank" href="surf.php">Traffic Exchange</a></div>';
	}else{
		return $menu . '<div class="ucp_link'.$selected.'"><a href="p.php?p=surf">Traffic Exchange</a></div>';
	}
}

register_filter('site_menu','surf_site_menu');
function surf_site_menu($menu) {
    $selected = "";
    if(isset($_GET["p"]) && $_GET["p"] == "surf")
    {
        $selected = 'selected';
    }
    else
    {
        $selected = 'value="surf"';
    }
	return $menu . '<option '.$selected.'>Traffic Exchange</a>';
}

register_filter('surf_info','surf_info');
function surf_info($type) {
    if($type == "db")
    {
        return "surf";
    }
    else if($type == "type")
    {
        return "Surf";
    }
	else if($type == "name")
    {
        return "Traffic Exchange";
    }
}

register_filter('surf_dtf','surf_dtf');
function surf_dtf($type) {
    return "surf";
}

register_filter('add_site_select','surf_add_select');
function surf_add_select($menu) {
    return $menu . "<option value='surf'>Traffic Exchange</option>";
}

register_filter('stats','surf_stats');
function surf_stats($stats) {
	global $db;
	$sql = $db->Query("SELECT module_name,value FROM `web_stats` WHERE `module_id`='surf'");
	if($db->GetNumRows($sql) == 0){
		$result = $db->FetchArray($sql);
		$sql = $db->Query("SELECT SUM(`clicks`) AS `clicks` FROM `surf`");
		$clicks = $db->FetchArray($sql);
		$clicks = ($clicks['clicks'] > 0 ? $clicks['clicks'] : 0);
		$db->Query("INSERT INTO `web_stats` (`module_id`,`module_name`,`value`)VALUES('surf','Traffic Exchange','".$clicks."')");
	}else{
		$result = $db->FetchArray($sql);
		$clicks = ($result['value'] > 0 ? $result['value'] : 0);
	}

    $stat = $db->QueryGetNumRows("SELECT id FROM `surf`");
    return $stats . "<tr><td>".$result['module_name']."</td><td>".number_format($stat)."</td><td>".number_format($clicks)."</td></tr>";
}

register_filter('tot_clicks','surf_tot_clicks');
function surf_tot_clicks($stats) {
	global $db;
    $clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='surf'"));
    if(empty($clicks['value']) && $clicks['value'] != '0'){
		$sql = $db->Query("SELECT SUM(`clicks`) AS `value` FROM `surf`");
		$clicks = $db->FetchArray($sql);
	}
	return $stats += ($clicks['value'] > 0 ? $clicks['value'] : 0);
}

register_filter('tot_sites','surf_tot_sites');
function surf_tot_sites($stats) {
	global $db;
    $clicks = $db->QueryGetNumRows("SELECT id FROM `surf`");
    return $stats += $clicks;
}

//Admin
register_filter('admin_s_sites','surf_admin_clicks');
function surf_admin_clicks($stats) {
	global $db;
	$clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='surf'"));
	$clicks = ($clicks['value'] > 0 ? $clicks['value'] : 0);
	$today_clicks = $db->FetchArray($db->Query("SELECT SUM(today_clicks) AS value FROM `user_clicks` WHERE `module`='surf'"));
	$today_clicks = ($today_clicks['value'] > 0 ? $today_clicks['value'] : 0);
	$active = $db->QueryGetNumRows("SELECT id FROM `surf`");
	$inactive = $db->QueryGetNumRows("SELECT id FROM `surf` WHERE `active`!='0'");
	return $stats . '<div class="full-stats">
							<h2 class="center">Traffic Exchange</h2>
							<div class="stat circular" data-valueFormat="0,0" data-list=\'[{"title":"Pages","val":'.$active.',"percent":'.round((($active - $inactive)/$active)*100, 0).'},{"title":"Clicks","val":'.$clicks.',"percent":0},{"title":"Today Clicks","val":'.$today_clicks.',"percent":0}]\'></div>
						</div>';
}

register_filter('admin_s_menu','surf_admin_menu');
function surf_admin_menu($menu) {
	return $menu . '<li><a href="index.php?x=sites&s=surf">Traffic Exchange</a></li>';
}
?>