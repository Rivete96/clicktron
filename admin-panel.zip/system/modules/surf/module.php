<?if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
if($site['surf_type'] == 0){
	redirect('index.php');
	exit;
}elseif($site['surf_type'] == 2){
	if($site['target_system'] != 2){
		$dbt_value = " AND (a.country = '".$data['country']."' OR a.country = '0') AND (a.sex = '".$data['sex']."' OR a.sex = '0')";
	}
	$sql = $db->Query("SELECT a.id FROM surf a LEFT JOIN users b ON b.id = a.user LEFT JOIN surfed c ON c.user = '".$data['id']."' AND c.site = a.id WHERE a.active = '0' AND (b.coins >= a.cpc AND a.cpc >= '2') AND (c.site IS NULL AND a.user !='".$data['id']."')".$dbt_value." ORDER BY a.cpc DESC, b.premium DESC LIMIT 1");
	$check = $db->GetNumRows($sql);
if($check == 0){
?>
<div class="msg"><div class="error"><?=$lang['b_163']?></div><div class="info"><a href="buy.php"><b><?=$lang['b_164']?></b></a></div></div>
<?}else{?>
<script type="text/javascript">
var msg1 = '<?=mysql_escape_string($lang['surf_09'])?>';
var msg2 = '<?=mysql_escape_string($lang['surf_10'])?>';
var msg3 = '<?=mysql_escape_string($lang['surf_11'])?>';
var msg4 = '<?=mysql_escape_string($lang['b_163'])?>';
var msg5 = '<?=mysql_escape_string($lang['surf_12'])?>';
var msg6 = '<?=mysql_escape_string($lang['b_156'])?>';
var report_msg1 = '<?=mysql_escape_string($lang['b_277'])?>';
var report_msg2 = '<?=mysql_escape_string($lang['b_236'])?>';
var report_msg3 = '<?=mysql_escape_string($lang['b_237'])?>';
var report_msg4 = '<?=mysql_escape_string(lang_rep($lang['b_252'], array('-NUM-' => $site['report_limit'])))?>';
var hideref = <?=($site['hideref'] != '' ? $site['hideref'] : 0)?>;
var rs_key = '<?=($site['revshare_api'] != '' ? $site['revshare_api'] : 0)?>';
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 4;6 L=M.y/2-1q;6 N=M.O/2-1r;6 z=\'1s=f,1t=f,1u=f,1v=f,1w=f,1x=P,1y=P,1z=f,y=1A,O=1B,1C=\'+N+\',1D=\'+L;3 1E(){7(4){Q()}g{R();A()}}3 R(){4=S.T(\'1F:1G\',"U",z);B()}3 B(){7(!4||4.C){}g{$.j({k:"D",8:"l/V/E/W.m",n:h,F:"1H=1",o:3(a){X(a){G\'1I\':Y();i;Z:6 b=1J.1K(a);6 c=b[\'8\'];7(p==1){c=\'10://p.11/?\'+b[\'8\']}g 7(p==2&&12!=\'0\'){c=\'10://1L.p.11/r/\'+12+\'/\'+b[\'8\']}4=S.T(c,"U",z);13(b[\'H\'],b[\'14\']);$(\'#q\').15();$(\'#q\').9(\'<5 16="1M:#1N;1O:1P 1Q;17:#18;y:1R;1S:1T;19-1U:1V"><1a 1b="I">\'+b[\'14\']+\'</1a> <a 1c="\'+b[\'8\']+\'" 1W="1X" 16="17:#18"><b>\'+b[\'1d\']+\'</b></a> <a 1c="1Y:1Z(0);" 20="1e(\\\'\'+b[\'H\']+\'\\\',\\\'\'+b[\'21\']+\'\\\',\\\'E\\\');"><1f 22="1f/1g.23" 24="1h" 1d="1h" 19="0" /></a><25 />\'+26+\' \'+b[\'27\']+\' \'+28+\'</5>\');i}}});$(\'#s\').9(29)}}6 t;3 13(b,c){t=J(3(){$.j({k:"D",8:"l/V/E/W.m",n:h,F:"2a=1&H="+b,o:3(a){B()}})},(c*1i));u((c-1),1);1j()}3 v(){u(0,0);t=1k(t);4=h}6 w;3 u(a,b){7(a>0){$(\'#I\').9(a);w=J(\'u(\'+(a-1)+\', 1);\',1i)}g{$(\'#I\').9(\'0\')}7(b==0){w=1k(w)}}3 Y(){4.1l();$(\'#q\').1m();$(\'#s\').1m();$(\'#1n\').15();$(\'#1n\').9(\'<5 x="1o"><5 x="2b">\'+2c+\'</5></5>\');v()}3 Q(){7(4){4.1l();$(\'#s\').9(1p);v()}}3 A(){7(!4||4.C||4.C==\'2d\'){$(\'#q\').9(\'<5 x="1o"><5 x="2e">\'+2f+\'</5></5>\');$(\'#s\').9(1p);v()}g{J(3(){A()},2g)}}3 1j(){$.j({k:"2h",8:"l/2i.m",n:h,o:3(a){$("#2j").9(a)}})}3 1e(a,b,c){6 e=2k(2l);7(e){$.j({k:"D",8:"l/1g.m",n:h,F:"1b="+a+"&8="+b+"&2m="+c+"&2n="+e,o:3(d){X(d){G\'1\':K(2o);2p(a,\'1\');i;G\'2\':K(2q);i;Z:K(2r);i}}})}}',62,152,'|||function|surfWindow|div|var|if|url|html||||||no|else|false|break|ajax|type|system|php|cache|success|hideref|surfInfo||surfButton|exe_count|displayCountdown|stopExec|exe_cd|class|width|surfWindowParams|checkWin|openWin|closed|POST|surf|data|case|sid|countDown|setTimeout|alert|aLeft|screen|aTop|height|yes|closeWin|emptyWindow|window|open|TrafficExchange|modules|process|switch|noSites|default|http|org|rs_key|startExec|time|show|style|color|171717|border|span|id|href|title|report_page|img|report|Report|1000|refresh_coins|clearTimeout|close|hide|surfHint|msg|msg2|400|300|toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|800|600|top|left|startSurf|about|blank|get|NO_SITE|jQuery|parseJSON|rs|background|efefef|margin|2px|auto|280px|padding|4px|radius|3px|target|_blank|javascript|void|onclick|eurl|src|png|alt|br|msg1|cpc|msg6|msg3|complete|info|msg4|undefined|error|msg5|200|GET|uCoins|c_coins|prompt|report_msg1|module|reason|report_msg2|skipuser|report_msg4|report_msg3'.split('|'),0,{}))
</script>
<h2 class="title"><?=$lang['b_162']?> - Traffic Exchange</h2>
<div class="infobox"><?=$lang['surf_13']?></div><br />
<div id="surfHint" style="display:none"></div><div id="surfInfo" style="display:none"></div>
<button id="surfButton" class="bbut" style="color:#fff" onclick="javascript:startSurf()"><?=$lang['surf_10']?></button>
<?}}else{?>
<h2 class="title"><?=$lang['b_162']?> - Traffic Exchange</h2>
<?
$dbt_value = '';
if($site['target_system'] != 2){
	$dbt_value = " AND (a.country = '".$data['country']."' OR a.country = '0') AND (a.sex = '".$data['sex']."' OR a.sex = '0')";
}

$sql = $db->Query("SELECT a.id, a.url, a.title, a.cpc, b.premium FROM surf a LEFT JOIN users b ON b.id = a.user LEFT JOIN surfed c ON c.user = '".$data['id']."' AND c.site = a.id WHERE a.confirm = '0' AND  a.active = '0' AND (b.coins >= a.cpc AND a.cpc >= '2') AND (c.site IS NULL AND a.user !='".$data['id']."')".$dbt_value." ORDER BY a.cpc DESC, b.premium DESC".($site['mysql_random'] == 1 ? ', RAND()' : '')." LIMIT 14");
$sites = $db->FetchArrayAll($sql);
if($sites != FALSE){
?>
<script type="text/javascript">
	var report_msg1 = '<?=mysql_escape_string($lang['b_277'])?>';
	var report_msg2 = '<?=mysql_escape_string($lang['b_236'])?>';
	var report_msg3 = '<?=mysql_escape_string($lang['b_237'])?>';
	var report_msg4 = '<?=mysql_escape_string(lang_rep($lang['b_252'], array('-NUM-' => $site['report_limit'])))?>';
	var base = '<?=$site['site_url']?>';
	var start_click = 1;
	var end_click = <?=$db->GetNumRows($sql)?>;
	eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('4 7(a,b,c){8 e=9(f);g(e){$.h({i:"j",5:"k/l.m",n:o,p:"q="+a+"&5="+b+"&r="+c+"&s="+e,t:4(d){u(d){6\'1\':0(v);w(a,\'1\');3;6\'2\':0(x);3;y:0(z);3}}})}}',36,36,'alert|||break|function|url|case|report_page|var|prompt||||||report_msg1|if|ajax|type|POST|system|report|php|cache|false|data|id|module|reason|success|switch|report_msg2|skipuser|report_msg4|default|report_msg3'.split('|'),0,{}))
	eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('3 8(){o(4<p){4=4+1}q{r.s(t)}}3 u(a){v=w(x+"/9.c?y="+a+"&z="+A.B(),"C");5(a)}3 D(b){d.e("6").f.g="E";$("#6").h("<i F=\\"2\\" G=\\"0\\" H=\\"I\\" J=\\"7\\" K=\\"L\\"><j><k><7><l M=2><b>N... <m O=\\"m/n-P.Q\\"></b></l></7></k></j></i><R>");$.n({S:"T",U:"V/W/9/X.c?Y=Z",10:"11="+b,12:3(a){$("#6").h(a)}});5(b)}3 5(a){d.e(a).f.g="13";8()}',62,66,'|||function|start_click|remove|txtHint|center|click_refresh|surf|||php|document|getElementById|style|display|html|table|tr|td|font|img|ajax|if|end_click|else|location|reload|true|opensite|childWindow|open|base|sid|rand|Math|random|View|skipuser|block|cellpadding|cellspacing|width|500|align|class|maintable|size|Skipping|src|loader|gif|br|type|GET|url|system|modules|process|step|skip|data|id|success|none'.split('|'),0,{}))
</script>
<div id="txtHint" style="display:none;"></div>
<div id="getpoints">
<?
  foreach($sites as $sit){
?>	
<div class="follow<?=($sit['premium'] > 0 ? '_vip' : '')?>" id="<?=$sit['id']?>">
	<center>
		<?=truncate($sit['title'], 11)?><br /><br /><b><?=$lang['b_42']?></b>: <?=($sit['cpc']-1)?><br>
		<a href="javascript:void(0);" onclick="opensite('<?=$sit['id']?>');" class="followbutton"><?=$lang['surf_04']?></a>
		<font style="font-size:0.8em;">[<a href="javascript:void(0);" onclick="skipuser('<?=$sit['id']?>');" style="color: #999999;font-size:0.9em;"><?=$lang['surf_05']?></a>]</font>
		<span style="position:absolute;bottom:1px;right:2px;"><a href="javascript:void(0);" onclick="report_page('<?=$sit['id']?>','<?=base64_encode($sit['url'])?>','surf');"><img src="img/report.png" alt="Report" title="Report" border="0" /></a></span>
	</center>
</div>
<?}?>
</div>
<?}else{?>
<div class="err1"><?=$lang['b_163']?></div>
<div class="not1"><a style="color:black" href="buy.php"><u><?=$lang['b_164']?></u></a></div>
<?}}?>