<?
define('BASEPATH', true);
include('../../config.php');
if(!$is_online){exit;}

if($site['surf_type'] == 2){
	if(isset($_POST['get']) && !empty($data['id'])){
		if($site['target_system'] != 2){
			$dbt_value = " AND (a.country = '".$data['country']."' OR a.country = '0') AND (a.sex = '".$data['sex']."' OR a.sex = '0')";
		}
		$sql = $db->Query("SELECT a.id, a.url, a.title, a.cpc, b.premium FROM surf a LEFT JOIN users b ON b.id = a.user LEFT JOIN surfed c ON c.user = '".$data['id']."' AND c.site = a.id WHERE a.active = '0' AND (b.coins >= a.cpc AND a.cpc >= '2') AND (c.site IS NULL AND a.user !='".$data['id']."')".$dbt_value." ORDER BY a.cpc DESC, b.premium DESC, RAND() LIMIT 1");
		$sit = $db->FetchArray($sql);

		if($sit['id'] > 0){
			$surf_time = $site['surf_time'];
			if($site['surf_time_type'] == 1){
				$surf_time = ($site['surf_time']*($sit['cpc']-1));
			}
			$key = ($surf_time+time());
			if($db->QueryGetNumRows("SELECT ses_key FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='surf'") == 0){
				$result	= $db->Query("INSERT INTO `module_session` (`user_id`,`page_id`,`ses_key`,`module`,`timestamp`)VALUES('".$data['id']."','".$sit['id']."','".$key."','surf','".time()."')");
			}else{
				$result	= $db->Query("UPDATE `module_session` SET `ses_key`='".$key."' WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='surf'");
			}
			$arr = array('url' => $sit['url'], 'cpc' => ($sit['cpc']-1), 'sid' => $sit['id'], 'title' => $sit['title'], 'eurl' => base64_encode($sit['url']), 'time' => $surf_time);
			echo json_encode($arr);
		}else{
			echo 'NO_SITE';
		}
	}elseif(isset($_POST['complete']) && isset($_POST['sid']) && !empty($data['id'])){
		$sid = $db->EscapeString($_POST['sid']);
		$sit = $db->FetchArray($db->Query("SELECT id,user,cpc FROM `surf` WHERE `id`='".$sid."'"));
		$check = $db->QueryGetNumRows("SELECT site FROM `surfed` WHERE `user`='".$data['id']."' AND `site`='".$sid."'");
			
		$mod_ses = $db->FetchArray($db->Query("SELECT ses_key FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='surf'"));
		$valid = false;
		if($mod_ses['ses_key'] != '' && ($mod_ses['ses_key']-5) <= time()){
			$valid = true;
		}

		if($valid && $sit['id'] != "" && $check == 0 && $sit['cpc'] >= 2){
			$db->Query("UPDATE `users` SET `coins`=`coins`+'".($sit['cpc']-1)."' WHERE `id`='".$data['id']."'");
			$db->Query("UPDATE `users` SET `coins`=`coins`-'".$sit['cpc']."' WHERE `id`='".$sit['user']."'");
			$db->Query("UPDATE `surf` SET `clicks`=`clicks`+'1' WHERE `id`='".$sit['id']."'");
			$db->Query("UPDATE `web_stats` SET `value`=`value`+'1' WHERE `module_id`='surf'");
			$db->Query("INSERT INTO `surfed` (user, site) VALUES('".$data['id']."', '".$sit['id']."')");
			$db->Query("DELETE FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='surf'");

			if($db->QueryGetNumRows("SELECT uid FROM `user_clicks` WHERE `uid`='".$data['id']."' AND `module`='surf' LIMIT 1") == 0){
				$db->Query("INSERT INTO `user_clicks` (`uid`,`module`,`total_clicks`,`today_clicks`)VALUES('".$data['id']."','surf','1','1')");
			}else{
				$db->Query("UPDATE `user_clicks` SET `total_clicks`=`total_clicks`+'1', `today_clicks`=`today_clicks`+'1' WHERE `uid`='".$data['id']."' AND `module`='surf'");
			}
		}
		echo '1';
	}
}else{
	if(isset($_GET['step']) && $_GET['step'] == "skip" && $_GET['id'] != '' && is_numeric($_GET['id'])){
		$id = $db->EscapeString($_GET['id']);
		if($db->QueryGetNumRows("SELECT site FROM `surfed` WHERE `user`='".$data['id']."' AND `site`='".$id."'") == 0){
			$db->Query("INSERT INTO `surfed` (user, site) VALUES('".$data['id']."', '".$id."')");
			echo '<div class="msg"><div class="info">'.$lang['surf_06'].'</div></div>';
		}
	}

	if(isset($_POST['data'])){
		$sid = $db->EscapeString($_POST['data']);
		$sit = $db->FetchArray($db->Query("SELECT id,user,cpc FROM `surf` WHERE `id`='".$sid."'"));
		$check = $db->QueryGetNumRows("SELECT site FROM `surfed` WHERE `user`='".$data['id']."' AND `site`='".$sid."'");
			
		$mod_ses = $db->FetchArray($db->Query("SELECT ses_key FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='surf'"));
		$valid = false;
		if($mod_ses['ses_key'] != '' && ($mod_ses['ses_key']-2) <= time()){
			$valid = true;
		}
		
		if($valid && $sit['id'] != "" && $check == 0 && $sit['cpc'] >= 2){
			$db->Query("UPDATE `users` SET `coins`=`coins`+'".($sit['cpc']-1)."' WHERE `id`='".$data['id']."'");
			$db->Query("UPDATE `users` SET `coins`=`coins`-'".$sit['cpc']."' WHERE `id`='".$sit['user']."'");
			$db->Query("UPDATE `surf` SET `clicks`=`clicks`+'1' WHERE `id`='".$sit['id']."'");
			$db->Query("UPDATE `web_stats` SET `value`=`value`+'1' WHERE `module_id`='surf'");
			$db->Query("INSERT INTO `surfed` (user, site) VALUES('".$data['id']."', '".$sit['id']."')");
			$db->Query("DELETE FROM `module_session` WHERE `user_id`='".$data['id']."' AND `page_id`='".$sit['id']."' AND `module`='surf'");

			if($db->QueryGetNumRows("SELECT uid FROM `user_clicks` WHERE `uid`='".$data['id']."' AND `module`='surf' LIMIT 1") == 0){
				$db->Query("INSERT INTO `user_clicks` (`uid`,`module`,`total_clicks`,`today_clicks`)VALUES('".$data['id']."','surf','1','1')");
			}else{
				$db->Query("UPDATE `user_clicks` SET `total_clicks`=`total_clicks`+'1', `today_clicks`=`today_clicks`+'1' WHERE `uid`='".$data['id']."' AND `module`='surf'");
			}

			if(isset($_POST['cpc'])){
				echo '<div class="msg">'.lang_rep($lang['surf_08'], array('-NUM-' => ($sit['cpc']-1))).'</div>';
			}
		}elseif(isset($_POST['cpc'])){
			echo '<div class="errormsg">'.$lang['surf_07'].'</div>';
		}
	}
}
?>