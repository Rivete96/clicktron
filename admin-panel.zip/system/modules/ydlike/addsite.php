<?php
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
$url = $db->EscapeString($_POST['url']);
$title = $db->EscapeString($_POST['title']);

if(empty($title) || empty($url)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_25'].'</div></div>';
}elseif(!preg_match('/^(http|https):\/\/[a-z0-9_]+([\-\.]{1}[a-z_0-9]+)*\.[_a-z]{2,5}'.'((:[0-9]{1,5})?\/.*)?$/i', $url)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_27'].'</div></div>';
}elseif(!preg_match("/^[A-Za-z0-9-_.!?]([A-Za-z\s]*[A-Za-z0-9-_.!?()])*$/", $title)){
	$msg = '<div class="msg"><div class="error">'.$lang['b_28'].'</div></div>';
}elseif($_POST['cpc'] < 2 || $_POST['cpc'] > $maxcpc){
	$msg = '<div class="msg"><div class="error">'.lang_rep($lang['b_29'], array('-MIN-' => '2', '-MAX-' => $maxcpc)).'</div></div>';
}elseif($gender < 0 || $gender > 2) {
	$msg = '<div class="msg"><div class="error">'.$lang['b_219'].'</div></div>';
}elseif(!in_array($country, $ctrs) && $country != '0') {
	$msg = '<div class="msg"><div class="error">'.$lang['b_220'].'</div></div>';
}else{
	if(preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+(?=\?)|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $url)){
		preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+(?=\?)|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $url, $matches);
		$vid = str_replace(' ', '', $matches[0]);
	}else{
		$vid = '0';
	}
	
	function check_likes($url){
		$url = get_data('https://gdata.youtube.com/feeds/api/videos/' . $url . '?v=2&alt=json');
		$entry = json_decode($url); 
		$attrs = $entry->{'entry'}->{'yt$rating'}->{'numLikes'};
		if(!empty($attrs)){
			return 1;
		}else{
			return 0;
		}
	}

	$sql = $db->Query("SELECT * FROM `ydlike` WHERE `url`='".$vid."' AND `user`='".$data['id']."'");
	$num = $db->GetNumRows($sql);
	if($num > 0){
		$msg = '<div class="msg"><div class="error">'.$lang['ylike_01'].'</div></div>';
	}elseif($vid == '0' || $vid == ''){
		$msg = '<div class="msg"><div class="error">'.$lang['ylike_02'].'</div></div>';
	}elseif(check_likes($vid) == 0){
		$msg = '<div class="msg"><div class="error">'.$lang['ylike_14'].'</div></div>';
	}else{
		$db->Query("INSERT INTO `ydlike` (user, url, title, cpc, country, sex) VALUES('".$data['id']."', '".$vid."', '".$title."', '".$cpc."', '".$country."', '".$gender."') ");
		$msg = '<div class="msg"><div class="success">'.$lang['ylike_03'].'</div></div>';
		$error = 0;
	}
}
?>