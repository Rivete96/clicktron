
--
-- Tabellenstruktur f�r Tabelle `ydlike`
--

CREATE TABLE IF NOT EXISTS `ydlike` (
  `id` int(255) NOT NULL auto_increment,
  `user` int(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `clicks` int(255) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `cpc` int(11) NOT NULL default '2',
  `country` varchar(64) NOT NULL default '0',
  `sex` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten f�r Tabelle `ydlike`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur f�r Tabelle `ydliked`
--

CREATE TABLE IF NOT EXISTS `ydliked` (
  `user_id` int(255) NOT NULL,
  `site_id` int(255) NOT NULL,
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten f�r Tabelle `ydliked`
--


-- --------------------------------------------------------