<?php
if(!mysql_num_rows(mysql_query("SHOW TABLES LIKE 'ydlike'"))){executeSql("system/modules/ydlike/db.sql");}

register_filter('index_icons_on','ydlike_icon_on');
function ydlike_icon_on($icons) {
	return $icons . '<a href="p.php?p=ydlike"><img class="exchange_icon" src="img/icons/ydlike.png" alt="YdLike" /></a>';
}

register_filter('index_icons_off','ydlike_icon_off');
function ydlike_icon_off($icons) {
	return $icons . '<img class="exchange_icon" src="img/icons/ydlike.png" alt="YdLike" />';
}
            
register_filter('top_menu_earn','ydlike_top_menu');
function ydlike_top_menu($menu) {
	$selected = (isset($_GET["p"]) && $_GET["p"] == "ydlike" ? ' active' : '');
	return $menu . '<div class="ucp_link'.$selected.'"><a href="p.php?p=ydlike">Youtube Dislikes</a></div>';
}

register_filter('site_menu','ydlike_site_menu');
function ydlike_site_menu($menu) {
    $selected = "";
    if(isset($_GET["p"]) && $_GET["p"] == "ydlike")
    {
        $selected = 'selected';
    }
    else
    {
        $selected = 'value="ydlike"';
    }
	return $menu . '<option '.$selected.'>Youtube Dislikes</a>';
}

register_filter('ydlike_info','ydlike_info');
function ydlike_info($type) {
    if($type == "db")
    {
        return "ydlike";
    }
    else if($type == "type")
    {
        return "Youtube Dislikes";
    }
	else if($type == "name")
    {
        return "Youtube Dislikes";
    }
}

register_filter('ydlike_dtf','ydlike_dtf');
function ydlike_dtf($type) {
    return "ydlike";
}

register_filter('add_site_select','ydlike_add_select');
function ydlike_add_select($menu) {
    return $menu . "<option value='ydlike'>Youtube Dislikes</option>";
}

register_filter('stats','ydlike_stats');
function ydlike_stats($stats) {
	global $db;
	$sql = $db->Query("SELECT module_name,value FROM `web_stats` WHERE `module_id`='ydlike'");
	if($db->GetNumRows($sql) == 0){
		$result = $db->FetchArray($sql);
		$sql = $db->Query("SELECT SUM(`clicks`) AS `clicks` FROM `ydlike`");
		$clicks = $db->FetchArray($sql);
		$clicks = ($clicks['clicks'] > 0 ? $clicks['clicks'] : 0);
		$db->Query("INSERT INTO `web_stats` (`module_id`,`module_name`,`value`)VALUES('ydlike','Youtube Dislikes','".$clicks."')");
	}else{
		$result = $db->FetchArray($sql);
		$clicks = ($result['value'] > 0 ? $result['value'] : 0);
	}

    $stat = $db->QueryGetNumRows("SELECT id FROM `ydlike`");
    return $stats . "<tr><td>".$result['module_name']."</td><td>".number_format($stat)."</td><td>".number_format($clicks)."</td></tr>";
}

register_filter('tot_clicks','ydlike_tot_clicks');
function ydlike_tot_clicks($stats) {
	global $db;
    $clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='ydlike'"));
    if(empty($clicks['value']) && $clicks['value'] != '0'){
		$sql = $db->Query("SELECT SUM(`clicks`) AS `value` FROM `ydlike`");
		$clicks = $db->FetchArray($sql);
	}
	return $stats += ($clicks['value'] > 0 ? $clicks['value'] : 0);
}

register_filter('tot_sites','ydlike_tot_sites');
function ydlike_tot_sites($stats) {
	global $db;
    $clicks = $db->QueryGetNumRows("SELECT id FROM `ydlike`");
    return $stats += $clicks;
}

//Admin
register_filter('admin_s_sites','ydlike_admin_clicks');
function ydlike_admin_clicks($stats) {
	global $db;
	$clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='ydlike'"));
	$clicks = ($clicks['value'] > 0 ? $clicks['value'] : 0);
	$today_clicks = $db->FetchArray($db->Query("SELECT SUM(today_clicks) AS value FROM `user_clicks` WHERE `module`='ydlike'"));
	$today_clicks = ($today_clicks['value'] > 0 ? $today_clicks['value'] : 0);
	$active = $db->QueryGetNumRows("SELECT id FROM `ydlike`");
	$inactive = $db->QueryGetNumRows("SELECT id FROM `ydlike` WHERE `active`!='0'");
	return $stats . '<div class="full-stats">
							<h2 class="center">Youtube Dislikes</h2>
							<div class="stat circular" data-valueFormat="0,0" data-list=\'[{"title":"Pages","val":'.$active.',"percent":'.round((($active - $inactive)/$active)*100, 0).'},{"title":"Clicks","val":'.$clicks.',"percent":0},{"title":"Today Clicks","val":'.$today_clicks.',"percent":0}]\'></div>
						</div>';
}

register_filter('admin_s_menu','ydlike_admin_menu');
function ydlike_admin_menu($menu) {
	return $menu . '<li><a href="index.php?x=sites&s=ydlike">YouTube Dislikes</a></li>';
}
?>