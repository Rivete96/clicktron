<?if(! defined('BASEPATH') ){ exit('Unable to view file.'); }?>
<?
$dbt_value = '';
if($site['target_system'] != 2){
	$dbt_value = " AND (a.country = '".$data['country']."' OR a.country = '0') AND (a.sex = '".$data['sex']."' OR a.sex = '0')";
}

$sql = $db->Query("SELECT a.id, a.url, a.title, a.cpc, b.premium FROM ydlike a LEFT JOIN users b ON b.id = a.user LEFT JOIN ydliked c ON c.user_id = '".$data['id']."' AND c.site_id = a.id WHERE a.active = '0' AND (b.coins >= a.cpc AND a.cpc >= '2') AND (c.site_id IS NULL AND a.user !='".$data['id']."')".$dbt_value." ORDER BY a.cpc DESC, b.premium DESC".($site['mysql_random'] == 1 ? ', RAND()' : '')." LIMIT 25");
$sites = $db->FetchArrayAll($sql);
if($sites != FALSE){
?>
<script>
	msg1 = '<?=mysql_escape_string($lang['ylike_09'])?>';
	msg2 = '<?=mysql_escape_string($lang['ylike_10'])?>';
	msg3 = '<?=mysql_escape_string($lang['ylike_11'])?>';
	msg4 = '<?=mysql_escape_string($lang['ylike_12'])?>';
	msg5 = '<?=mysql_escape_string($lang['ylike_13'])?>';
	var report_msg1 = '<?=mysql_escape_string($lang['b_277'])?>';
	var report_msg2 = '<?=mysql_escape_string($lang['b_236'])?>';
	var report_msg3 = '<?=mysql_escape_string($lang['b_237'])?>';
	var report_msg4 = '<?=mysql_escape_string(lang_rep($lang['b_252'], array('-NUM-' => $site['report_limit'])))?>';
	hideref = <?=($site['hideref'] != '' ? $site['hideref'] : 0)?>;
	rs_key = '<?=($site['revshare_api'] != '' ? $site['revshare_api'] : 0)?>';
	var start_click = 1;
	var end_click = <?=$db->GetNumRows($sql)?>;
	eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('4 7(a,b,c){8 e=9(f);g(e){$.h({i:"j",5:"k/l.m",n:o,p:"q="+a+"&5="+b+"&r="+c+"&s="+e,t:4(d){u(d){6\'1\':0(v);w(a,\'1\');3;6\'2\':0(x);3;y:0(z);3}}})}}',36,36,'alert|||break|function|url|case|report_page|var|prompt||||||report_msg1|if|ajax|type|POST|system|report|php|cache|false|data|id|module|reason|success|switch|report_msg2|skipuser|report_msg4|default|report_msg3'.split('|'),0,{}))
	eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('4 C(){8(D<15){D=D+1}p{S.16(17)}}4 18(b,c){$("#6").5("<m E=\\"m/F.G\\" /><H>");$.u({x:"I",q:"y/J/K/L.z",M:"19=1a&1b="+b,s:4(a){$("#6").5(a);N(b);C()}})}n o;4 1c(d,e,f,w,h,g,i){8(o&&!o.T){}p{n j=U.V/2-w/2;n k=U.W/2-h/2;n l="t://O.P.Q/R?v="+e;$("#6").5("<m E=\\"m/F.G\\" /><H>");$.u({x:"I",q:"y/J/K/L.z",M:"1d=1&q="+e+"&1e="+d,s:4(a){8(!1f(a)){$("#6").5("<3 7=\\"A\\"><3 7=\\"1g\\">"+1h+"</3></3>");n b=1i(4(){o.1j()},1k);n c=1l(4(){8(o.T){X(c);X(b);Y(d,g,i)}},1m)}p{$("#6").5("<3 7=\\"A\\"><3 7=\\"Z\\">"+1n+"</3></3>")}}});8(B==1){l=\'t://B.10/?t://O.P.Q/R?v=\'+e}p 8(B==2&&11!=\'0\'){l=\'t://1o.B.10/r/\'+11+\'/t://O.P.Q/R?v=\'+e}o=1p.1q(l,f,"1r=9, S=9, 1s=9, 1t=9, 1u=9, 1v=1w, 1x=9, 1y=9, V="+w+", W="+h+", 1z="+k+", 1A="+j)}}4 Y(b,c,e){$("#6").5("<m E=\\"m/F.G\\" /><H>");$.u({x:"I",q:"y/J/K/L.z",12:13,M:"1B="+b,s:4(a){8(a==1){$("#6").5("<3 7=\\"A\\"><3 7=\\"s\\">"+1C+" <b>"+c+"</b>"+1D+"</3></3>");N(b);C();14()}p{$("#6").5("<3 7=\\"A\\"><3 7=\\"Z\\">"+1E+"</3></3>")}}})}4 N(a){1F.1G(a).1H.1I="1J"}4 14(){$.u({x:"1K",q:"y/1L.z",12:13,s:4(a){$("#1M").5(a)}})}',62,111,'|||div|function|html|Hint|class|if|no|||||||||||||img|var|targetWin|else|url||success|http://anonymgoto.com/?u=http|ajax|||type|system|php|msg|hideref|click_refresh|start_click|src|loader|gif|br|POST|modules|ydlike|process|data|remove|www|youtube|com|watch|location|closed|screen|width|height|clearTimeout|do_click|error|org|rs_key|cache|false|refresh_coins|end_click|reload|true|skipuser|step|skip|sid|ModulePopup|get|pid|isNaN|info|msg1|setTimeout|close|20000|setInterval|1000|msg2|rs|window|open|toolbar|directories|status|menubar|scrollbars|yes|resizable|copyhistory|top|left|id|msg4|msg5|msg3|document|getElementById|style|display|none|GET|uCoins|c_coins'.split('|'),0,{}))
</script>
<center><div id="Hint"></div></center>
<div id="getpoints">
<?foreach($sites as $sit){?>	
<div class="follow<?=($sit['premium'] > 0 ? '_vip' : '')?>" id="<?=$sit['id']?>">
	<center>
		<img src="http://img.youtube.com/vi/<?=$sit['url']?>/1.jpg" width="70" height="70" alt="<?=truncate($sit['title'], 10)?>" title="<?=truncate($sit['title'], 50)?>" border="0" /><br />
<p></p><b><?=$lang['b_42']?></b>: <?=($sit['cpc']-1)?><br>
            <center><a href="javascript:void(0);" class="single_like_button btn3-wrap" onclick="ModulePopup('<?=$sit['id']?>','<?=$sit['url']?>','Youtube','840','850','<?=($sit['cpc']-1)?>','1');">
						                    <span></span><div class="btn3">Dislike</div></a></center>
		<font style="font-size:1.2em;"><a href="javascript:void(0);" onclick="skipuser('<?=$sit['id']?>','1');" style="color: black;font-size:0.9em;">Skip</a></font>
		<span style="position:absolute;bottom:60px;right:134px;"><a href="javascript:void(0);" onclick="report_page('<?=$sit['id']?>','<?=base64_encode('http://www.youtube.com/watch?v='.$sit['url'])?>','ylike');"><img src="img/report.png" alt="Report" title="Report" border="0" /></a></span>
	</center>
<style>
#hides { color: transparent; }
</style>
<pre id="hides">-
-
</pre>
</div>
<?}?>
</div>
<?}else{?>
<div class="err1"><?=$lang['b_163']?></div>
<div class="not1"><a style="color:black" href="buy.php"><u><?=$lang['b_164']?></u></a></div>
<?}?>