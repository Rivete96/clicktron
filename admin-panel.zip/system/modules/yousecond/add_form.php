<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label><?=$lang['ys_url']?></label> <small style="float:right"><?=$lang['ys_url_desc']?></small><br/>
	<input class="text-max" type="text" value="" name="url" />
</p>