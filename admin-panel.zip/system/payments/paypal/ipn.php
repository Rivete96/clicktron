<?php
define('BASEPATH', true);
require("../../config.php");

// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value) {
$value = urlencode(stripslashes($value));
$req .= "&$key=$value";
}

// post back to PayPal system to validate
$header .= "POST /cgi-bin/webscr HTTP/1.1\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Host: www.paypal.com\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

// assign posted variables to local variables
$item_name = $_POST['item_name'];
$item_number = $_POST['item_number'];
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$payment_currency = $_POST['mc_currency'];
$txn_id = $_POST['txn_id'];
$receiver_email = $_POST['receiver_email'];
$payer_email = $_POST['payer_email'];
$custom = $_POST['custom'];

if (!$fp) {
// HTTP ERROR
} else {
fputs ($fp, $header . $req);
while (!feof($fp)) {
	$res = fgets ($fp, 1024);
	if (strcmp ($res, "VERIFIED") == 0) {
		$get_data = explode('|', $custom); 
		
		if($site['paypal_auto'] == 1){
			if($payment_status == 'Completed'){
				$user = $db->FetchArray($db->Query("SELECT id,login,ref FROM `users` WHERE `id`='".$get_data[0]."'"));
				$check = $db->QueryGetNumRows("SELECT id FROM `transactions` WHERE `gateway`='paypal' AND `trans_id`='".$txn_id."'");
				if($check == 0){
					$db->Query("INSERT INTO `transactions` (user, user_id, money, gateway, date, user_ip, trans_id) VALUES('".$user['login']."','".$user['id']."', '".$payment_amount."', 'paypal', NOW(), '".$get_data[2]."', '".$txn_id."')");
					if($user['id'] > 0){
						if($site['paysys'] == 1 && $user['ref'] > 0 && $payment_amount > 0){
							$cash = number_format(($payment_amount/100) * $site['ref_sale'], 2);
							$db->Query("UPDATE `users` SET `account_balance`=`account_balance`+'".$cash."' WHERE `id`='".$user['ref']."'");	
						}
						$db->Query("UPDATE `users` SET `account_balance`=`account_balance`+'".$payment_amount."' WHERE `id`='".$user['id']."'");			
					}
				}
			}
		}else{
			$user = $db->FetchArray($db->Query("SELECT id,login,ref FROM `users` WHERE `id`='".$get_data[0]."'"));
			$check = $db->QueryGetNumRows("SELECT id FROM `transactions` WHERE `gateway`='paypal' AND `trans_id`='".$txn_id."'");
			if($check == 0){
				$db->Query("INSERT INTO `transactions` (user, user_id, money, gateway, date, paid, user_ip, trans_id) VALUES('".$user['login']."','".$user['id']."', '".$payment_amount."', 'paypal', NOW(), '0', '".$get_data[2]."', '".$txn_id."')");
				if($site['paysys'] == 1 && $user['ref'] > 0 && $payment_amount > 0){
					$cash = number_format(($payment_amount/100) * $site['ref_sale'], 2);
					$db->Query("UPDATE `users` SET `account_balance`=`account_balance`+'".$cash."' WHERE `id`='".$user['ref']."'");	
				}
			}
		}
	}
}
fclose ($fp);
}
?>