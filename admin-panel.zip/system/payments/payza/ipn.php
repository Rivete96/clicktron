<?php
define('BASEPATH', true);
require("../../config.php");

//The value is the Security Code generated from the IPN section of your Payza account. Please change it to yours.
define("IPN_SECURITY_CODE", $site['payza_security']);
define("MY_MERCHANT_EMAIL", $site['payza']);

//Setting information about the transaction
$receivedSecurityCode = $_POST['ap_securitycode'];
$receivedMerchantEmailAddress = $_POST['ap_merchant'];	
$transactionStatus = $_POST['ap_status'];
$testModeStatus = $_POST['ap_test'];	
$AmountReceived = $_POST['ap_totalamount'];
$currency = $_POST['ap_currency']; 
$transactionID = $info['ap_referencenumber'];

//Setting extra information about the purchased item from the IPN post variables
$additionalCharges = $_POST['ap_additionalcharges'];
$shippingCharges = $_POST['ap_shippingcharges'];
$taxAmount = $_POST['ap_taxamount'];
$discountAmount = $_POST['ap_discountamount'];

if ($receivedMerchantEmailAddress == MY_MERCHANT_EMAIL) {
	if ($receivedSecurityCode == IPN_SECURITY_CODE) {
		if ($transactionStatus == "Success") {
			if ($testModeStatus != "1") {
				$get_data = explode('|', $_POST['apc_1']); 
				
				if($site['payza_auto'] == 1){
					$user = $db->FetchArray($db->Query("SELECT id,login,ref FROM `users` WHERE `id`='".$get_data[0]."'"));
					$check = $db->QueryGetNumRows("SELECT id FROM `transactions` WHERE `gateway`='payza' AND `trans_id`='".$transactionID."'");
					if($check == 0){
						$db->Query("INSERT INTO `transactions` (user, user_id, money, gateway, date, user_ip, trans_id) VALUES('".$user['login']."','".$user['id']."', '".$AmountReceived."', 'payza', NOW(), '".$get_data[2]."', '".$transactionID."')");
						if($user['id'] > 0){
							$db->Query("UPDATE `users` SET `account_balance`=`account_balance`+'".$AmountReceived."' WHERE `id`='".$user['id']."'");
							if($site['paysys'] == 1 && $user['ref'] > 0 && $AmountReceived > 0){
								$cash = number_format(($AmountReceived/100) * $site['ref_sale'], 2);
								$db->Query("UPDATE `users` SET `account_balance`=`account_balance`+'".$cash."' WHERE `id`='".$user['ref']."'");	
							}
						}
					}
				}else{
					$user = $db->FetchArray($db->Query("SELECT id,login,ref FROM `users` WHERE `id`='".$get_data[0]."'"));
					$check = $db->QueryGetNumRows("SELECT id FROM `transactions` WHERE `gateway`='payza' AND `trans_id`='".$transactionID."'");
					if($check == 0){
						$db->Query("INSERT INTO `transactions` (user, user_id, money, gateway, date, paid, user_ip, trans_id) VALUES('".$user['login']."','".$user['id']."', '".$AmountReceived."', 'payza', NOW(), '0', '".$get_data[2]."', '".$transactionID."')");
						if($user['id'] > 0){
							if($site['paysys'] == 1 && $user['ref'] > 0 && $AmountReceived > 0){
								$cash = number_format(($AmountReceived/100) * $site['ref_sale'], 2);
								$db->Query("UPDATE `users` SET `account_balance`=`account_balance`+'".$cash."' WHERE `id`='".$user['ref']."'");	
							}
						}
					}
				}
			}			
		}
	}
}
?>