<?
define('BASEPATH', true);
require_once("config.php");
$db->Close();

if(!$is_online){
	exit;
}else{
	echo number_format($data['coins']);
}
?>
