<?
$config['version'] = '1.8';
?>